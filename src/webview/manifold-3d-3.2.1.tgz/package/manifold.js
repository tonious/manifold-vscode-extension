async function Module(moduleArg = {}) {
  var moduleRtn;
  var Module = moduleArg;
  var ENVIRONMENT_IS_WEB = typeof window == 'object';
  var ENVIRONMENT_IS_WORKER = typeof WorkerGlobalScope != 'undefined';
  var ENVIRONMENT_IS_NODE = typeof process == 'object' &&
      process.versions?.node && process.type != 'renderer';
  if (ENVIRONMENT_IS_NODE) {
    const {createRequire} = await import('module');
    var require = createRequire(import.meta.url)
  }
  var _ManifoldInitialized = false;
  Module.setup = function() {
    if (_ManifoldInitialized) return;
    _ManifoldInitialized = true;
    Module.initTBB();
    function toVec(vec, list, f = (x => x)) {
      if (list) {
        for (let x of list) {
          vec.push_back(f(x))
        }
      }
      return vec
    }
    function fromVec(vec, f = (x => x)) {
      const result = [];
      const size = vec.size();
      for (let i = 0; i < size; i++) result.push(f(vec.get(i)));
      return result
    }
    function vec2polygons(vec, f = (x => x)) {
      const result = [];
      const nPoly = vec.size();
      for (let i = 0; i < nPoly; i++) {
        const v = vec.get(i);
        const nPts = v.size();
        const poly = [];
        for (let j = 0; j < nPts; j++) {
          poly.push(f(v.get(j)))
        }
        result.push(poly)
      }
      return result
    }
    function polygons2vec(polygons) {
      if (polygons[0].length < 3) {
        polygons = [polygons]
      }
      return toVec(
          new Module.Vector2_vec2, polygons,
          poly => toVec(new Module.Vector_vec2, poly, p => {
            if (p instanceof Array) return {x: p[0], y: p[1]};
            return p
          }))
    }
    function disposePolygons(polygonsVec) {
      for (let i = 0; i < polygonsVec.size(); i++) polygonsVec.get(i).delete();
      polygonsVec.delete()
    }
    function vararg2vec2(vec) {
      if (vec[0] instanceof Array) return {x: vec[0][0], y: vec[0][1]};
      if (typeof vec[0] == 'number') return {x: vec[0] || 0, y: vec[1] || 0};
      return vec[0]
    }
    function vararg2vec3(vec) {
      if (vec[0] instanceof Array)
        return {x: vec[0][0], y: vec[0][1], z: vec[0][2]};
      if (typeof vec[0] == 'number')
        return {x: vec[0] || 0, y: vec[1] || 0, z: vec[2] || 0};
      return vec[0]
    }
    function fillRuleToInt(fillRule) {
      return fillRule == 'EvenOdd' ? 0 :
          fillRule == 'NonZero'    ? 1 :
          fillRule == 'Negative'   ? 3 :
                                     2
    }
    function joinTypeToInt(joinType) {
      return joinType == 'Round' ? 1 : joinType == 'Miter' ? 2 : 0
    }
    const CrossSectionCtor = Module.CrossSection;
    function cross(polygons, fillRule = 'Positive') {
      if (polygons instanceof CrossSectionCtor) {
        return polygons
      } else {
        const polygonsVec = polygons2vec(polygons);
        const cs = new CrossSectionCtor(polygonsVec, fillRuleToInt(fillRule));
        disposePolygons(polygonsVec);
        return cs
      }
    }
    Module.CrossSection.prototype.translate = function(...vec) {
      return this._Translate(vararg2vec2(vec))
    };
    Module.CrossSection.prototype.scale = function(vec) {
      if (typeof vec == 'number') {
        return this._Scale({x: vec, y: vec})
      }
      return this._Scale(vararg2vec2([vec]))
    };
    Module.CrossSection.prototype.mirror = function(vec) {
      return this._Mirror(vararg2vec2([vec]))
    };
    Module.CrossSection.prototype.warp = function(func) {
      const wasmFuncPtr = addFunction(function(vec2Ptr) {
        const x = getValue(vec2Ptr, 'double');
        const y = getValue(vec2Ptr + 8, 'double');
        const vert = [x, y];
        func(vert);
        setValue(vec2Ptr, vert[0], 'double');
        setValue(vec2Ptr + 8, vert[1], 'double')
      }, 'vi');
      const out = this._Warp(wasmFuncPtr);
      removeFunction(wasmFuncPtr);
      return out
    };
    Module.CrossSection.prototype.decompose = function() {
      const vec = this._Decompose();
      const result = fromVec(vec);
      vec.delete();
      return result
    };
    Module.CrossSection.prototype.bounds = function() {
      const result = this._Bounds();
      return {
        min: ['x', 'y'].map(f => result.min[f]),
            max: ['x', 'y'].map(f => result.max[f])
      }
    };
    Module.CrossSection.prototype.offset = function(
        delta, joinType = 'Round', miterLimit = 2, circularSegments = 0) {
      return this._Offset(
          delta, joinTypeToInt(joinType), miterLimit, circularSegments)
    };
    Module.CrossSection.prototype.simplify = function(epsilon = 1e-6) {
      return this._Simplify(epsilon)
    };
    Module.CrossSection.prototype.extrude = function(
        height, nDivisions = 0, twistDegrees = 0, scaleTop = [1, 1],
        center = false) {
      scaleTop = vararg2vec2([scaleTop]);
      const man = Module._Extrude(
          this._ToPolygons(), height, nDivisions, twistDegrees, scaleTop);
      return center ? man.translate([0, 0, -height / 2]) : man
    };
    Module.CrossSection.prototype.revolve = function(
        circularSegments = 0, revolveDegrees = 360) {
      return Module._Revolve(
          this._ToPolygons(), circularSegments, revolveDegrees)
    };
    Module.CrossSection.prototype.add = function(other) {
      return this._add(cross(other))
    };
    Module.CrossSection.prototype.subtract = function(other) {
      return this._subtract(cross(other))
    };
    Module.CrossSection.prototype.intersect = function(other) {
      return this._intersect(cross(other))
    };
    Module.CrossSection.prototype.toPolygons = function() {
      const vec = this._ToPolygons();
      const result = vec2polygons(vec, v => [v.x, v.y]);
      vec.delete();
      return result
    };
    Module.Manifold.prototype.smoothOut = function(
        minSharpAngle = 60, minSmoothness = 0) {
      return this._SmoothOut(minSharpAngle, minSmoothness)
    };
    Module.Manifold.prototype.warp = function(func) {
      const wasmFuncPtr = addFunction(function(vec3Ptr) {
        const x = getValue(vec3Ptr, 'double');
        const y = getValue(vec3Ptr + 8, 'double');
        const z = getValue(vec3Ptr + 16, 'double');
        const vert = [x, y, z];
        func(vert);
        setValue(vec3Ptr, vert[0], 'double');
        setValue(vec3Ptr + 8, vert[1], 'double');
        setValue(vec3Ptr + 16, vert[2], 'double')
      }, 'vi');
      const out = this._Warp(wasmFuncPtr);
      removeFunction(wasmFuncPtr);
      const status = out.status();
      if (status !== 'NoError') {
        throw new Module.ManifoldError(status)
      }
      return out
    };
    Module.Manifold.prototype.calculateNormals = function(
        normalIdx, minSharpAngle = 60) {
      return this._CalculateNormals(normalIdx, minSharpAngle)
    };
    Module.Manifold.prototype.setProperties = function(numProp, func) {
      const oldNumProp = this.numProp();
      const wasmFuncPtr = addFunction(function(newPtr, vec3Ptr, oldPtr) {
        const newProp = [];
        for (let i = 0; i < numProp; ++i) {
          newProp[i] = getValue(newPtr + 8 * i, 'double')
        }
        const pos = [];
        for (let i = 0; i < 3; ++i) {
          pos[i] = getValue(vec3Ptr + 8 * i, 'double')
        }
        const oldProp = [];
        for (let i = 0; i < oldNumProp; ++i) {
          oldProp[i] = getValue(oldPtr + 8 * i, 'double')
        }
        func(newProp, pos, oldProp);
        for (let i = 0; i < numProp; ++i) {
          setValue(newPtr + 8 * i, newProp[i], 'double')
        }
      }, 'viii');
      const out = this._SetProperties(numProp, wasmFuncPtr);
      removeFunction(wasmFuncPtr);
      return out
    };
    Module.Manifold.prototype.translate = function(...vec) {
      return this._Translate(vararg2vec3(vec))
    };
    Module.Manifold.prototype.rotate = function(xOrVec, y, z) {
      if (Array.isArray(xOrVec)) {
        return this._Rotate(...xOrVec)
      } else {
        return this._Rotate(xOrVec, y || 0, z || 0)
      }
    };
    Module.Manifold.prototype.scale = function(vec) {
      if (typeof vec == 'number') {
        return this._Scale({x: vec, y: vec, z: vec})
      }
      return this._Scale(vararg2vec3([vec]))
    };
    Module.Manifold.prototype.mirror = function(vec) {
      return this._Mirror(vararg2vec3([vec]))
    };
    Module.Manifold.prototype.trimByPlane = function(normal, offset = 0) {
      return this._TrimByPlane(vararg2vec3([normal]), offset)
    };
    Module.Manifold.prototype.slice = function(height = 0) {
      const polygonsVec = this._Slice(height);
      const result =
          new CrossSectionCtor(polygonsVec, fillRuleToInt('Positive'));
      disposePolygons(polygonsVec);
      return result
    };
    Module.Manifold.prototype.project = function() {
      const polygonsVec = this._Project();
      const result =
          new CrossSectionCtor(polygonsVec, fillRuleToInt('Positive'));
      disposePolygons(polygonsVec);
      return result
    };
    Module.Manifold.prototype.split = function(manifold) {
      const vec = this._Split(manifold);
      const result = fromVec(vec);
      vec.delete();
      return result
    };
    Module.Manifold.prototype.splitByPlane = function(normal, offset = 0) {
      const vec = this._SplitByPlane(vararg2vec3([normal]), offset);
      const result = fromVec(vec);
      vec.delete();
      return result
    };
    Module.Manifold.prototype.decompose = function() {
      const vec = this._Decompose();
      const result = fromVec(vec);
      vec.delete();
      return result
    };
    Module.Manifold.prototype.boundingBox = function() {
      const result = this._boundingBox();
      return {
        min: ['x', 'y', 'z'].map(f => result.min[f]),
            max: ['x', 'y', 'z'].map(f => result.max[f])
      }
    };
    class Mesh {
      constructor({
        numProp = 3,
        triVerts = new Uint32Array,
        vertProperties = new Float32Array,
        mergeFromVert,
        mergeToVert,
        runIndex,
        runOriginalID,
        faceID,
        halfedgeTangent,
        runTransform
      } = {}) {
        this.numProp = numProp;
        this.triVerts = triVerts;
        this.vertProperties = vertProperties;
        this.mergeFromVert = mergeFromVert;
        this.mergeToVert = mergeToVert;
        this.runIndex = runIndex;
        this.runOriginalID = runOriginalID;
        this.faceID = faceID;
        this.halfedgeTangent = halfedgeTangent;
        this.runTransform = runTransform
      }
      get numTri() {
        return this.triVerts.length / 3
      }
      get numVert() {
        return this.vertProperties.length / this.numProp
      }
      get numRun() {
        return this.runOriginalID.length
      }
      merge() {
        const {changed, mesh} = Module._Merge(this);
        Object.assign(this, {...mesh});
        return changed
      }
      verts(tri) {
        return this.triVerts.subarray(3 * tri, 3 * (tri + 1))
      }
      position(vert) {
        return this.vertProperties.subarray(
            this.numProp * vert, this.numProp * vert + 3)
      }
      extras(vert) {
        return this.vertProperties.subarray(
            this.numProp * vert + 3, this.numProp * (vert + 1))
      }
      tangent(halfedge) {
        return this.halfedgeTangent.subarray(4 * halfedge, 4 * (halfedge + 1))
      }
      transform(run) {
        const mat4 = new Array(16);
        for (const col of [0, 1, 2, 3]) {
          for (const row of [0, 1, 2]) {
            mat4[4 * col + row] = this.runTransform[12 * run + 3 * col + row]
          }
        }
        mat4[15] = 1;
        return mat4
      }
    }
    Module.Mesh = Mesh;
    Module.Manifold.prototype.getMesh = function(normalIdx = -1) {
      return new Mesh(this._GetMeshJS(normalIdx))
    };
    Module.ManifoldError = function ManifoldError(code, ...args) {
      let message = 'Unknown error';
      switch (code) {
        case 'NonFiniteVertex':
          message = 'Non-finite vertex';
          break;
        case 'NotManifold':
          message = 'Not manifold';
          break;
        case 'VertexOutOfBounds':
          message = 'Vertex index out of bounds';
          break;
        case 'PropertiesWrongLength':
          message = 'Properties have wrong length';
          break;
        case 'MissingPositionProperties':
          message = 'Less than three properties';
          break;
        case 'MergeVectorsDifferentLengths':
          message = 'Merge vectors have different lengths';
          break;
        case 'MergeIndexOutOfBounds':
          message = 'Merge index out of bounds';
          break;
        case 'TransformWrongLength':
          message = 'Transform vector has wrong length';
          break;
        case 'RunIndexWrongLength':
          message = 'Run index vector has wrong length';
          break;
        case 'FaceIDWrongLength':
          message = 'Face ID vector has wrong length';
        case 'InvalidConstruction':
          message = 'Manifold constructed with invalid parameters'
      }
      const base = Error.apply(this, [message, ...args]);
      base.name = this.name = 'ManifoldError';
      this.message = base.message;
      this.stack = base.stack;
      this.code = code
    };
    Module.ManifoldError.prototype = Object.create(Error.prototype, {
      constructor:
          {value: Module.ManifoldError, writable: true, configurable: true}
    });
    Module.CrossSection = function(polygons, fillRule = 'Positive') {
      const polygonsVec = polygons2vec(polygons);
      const cs = new CrossSectionCtor(polygonsVec, fillRuleToInt(fillRule));
      disposePolygons(polygonsVec);
      return cs
    };
    Module.CrossSection.ofPolygons = function(polygons, fillRule = 'Positive') {
      return new Module.CrossSection(polygons, fillRule)
    };
    Module.CrossSection.square = function(...args) {
      let size = undefined;
      if (args.length == 0)
        size = {x: 1, y: 1};
      else if (typeof args[0] == 'number')
        size = {x: args[0], y: args[0]};
      else
        size = vararg2vec2(args);
      const center = args[1] || false;
      return Module._Square(size, center)
    };
    Module.CrossSection.circle = function(radius, circularSegments = 0) {
      return Module._Circle(radius, circularSegments)
    };
    function crossSectionBatchbool(name) {
      return function(...args) {
        if (args.length == 1) args = args[0];
        const v = new Module.Vector_crossSection;
        for (const cs of args) v.push_back(cross(cs));
        const result = Module['_crossSection' + name](v);
        v.delete();
        return result
      }
    }
    Module.CrossSection.compose = crossSectionBatchbool('Compose');
    Module.CrossSection.union = crossSectionBatchbool('UnionN');
    Module.CrossSection.difference = crossSectionBatchbool('DifferenceN');
    Module.CrossSection.intersection = crossSectionBatchbool('IntersectionN');
    function pushVec2(vec, ps) {
      toVec(vec, ps, p => {
        if (p instanceof Array) return {x: p[0], y: p[1]};
        return p
      })
    }
    Module.CrossSection.hull = function(...args) {
      if (args.length == 1) args = args[0];
      let pts = new Module.Vector_vec2;
      for (const cs of args) {
        if (cs instanceof CrossSectionCtor) {
          Module._crossSectionCollectVertices(pts, cs)
        } else if (
            cs instanceof Array && cs.length == 2 && typeof cs[0] == 'number') {
          pts.push_back({x: cs[0], y: cs[1]})
        } else if (cs.x) {
          pts.push_back(cs)
        } else {
          const wrap =
              cs[0].length == 2 && typeof cs[0][0] == 'number' || cs[0].x;
          const polys = wrap ? [cs] : cs;
          for (const poly of polys) pushVec2(pts, poly)
        }
      }
      const result = Module._crossSectionHullPoints(pts);
      pts.delete();
      return result
    };
    Module.CrossSection.prototype = Object.create(CrossSectionCtor.prototype);
    Object.defineProperty(
        Module.CrossSection, Symbol.hasInstance,
        {get: () => t => t instanceof CrossSectionCtor});
    const ManifoldCtor = Module.Manifold;
    Module.Manifold = function(mesh) {
      const manifold = new ManifoldCtor(mesh);
      const status = manifold.status();
      if (status !== 'NoError') {
        throw new Module.ManifoldError(status)
      }
      return manifold
    };
    Module.Manifold.ofMesh = function(mesh) {
      return new Module.Manifold(mesh)
    };
    Module.Manifold.tetrahedron = function() {
      return Module._Tetrahedron()
    };
    Module.Manifold.cube = function(...args) {
      let size = undefined;
      if (args.length == 0)
        size = {x: 1, y: 1, z: 1};
      else if (typeof args[0] == 'number')
        size = {x: args[0], y: args[0], z: args[0]};
      else
        size = vararg2vec3(args);
      const center = args[1] || false;
      return Module._Cube(size, center)
    };
    Module.Manifold.cylinder = function(
        height, radiusLow, radiusHigh = -1, circularSegments = 0,
        center = false) {
      return Module._Cylinder(
          height, radiusLow, radiusHigh, circularSegments, center)
    };
    Module.Manifold.sphere = function(radius, circularSegments = 0) {
      return Module._Sphere(radius, circularSegments)
    };
    Module.Manifold.smooth = function(mesh, sharpenedEdges = []) {
      const sharp = new Module.Vector_smoothness;
      toVec(sharp, sharpenedEdges);
      const result = Module._Smooth(mesh, sharp);
      sharp.delete();
      return result
    };
    Module.Manifold.extrude = function(
        polygons, height, nDivisions = 0, twistDegrees = 0, scaleTop = [1, 1],
        center = false) {
      const cs = polygons instanceof CrossSectionCtor ?
          polygons :
          Module.CrossSection(polygons, 'Positive');
      return cs.extrude(height, nDivisions, twistDegrees, scaleTop, center)
    };
    Module.Manifold.revolve = function(
        polygons, circularSegments = 0, revolveDegrees = 360) {
      const cs = polygons instanceof CrossSectionCtor ?
          polygons :
          Module.CrossSection(polygons, 'Positive');
      return cs.revolve(circularSegments, revolveDegrees)
    };
    Module.Manifold.reserveIDs = function(n) {
      return Module._ReserveIDs(n)
    };
    Module.Manifold.compose = function(manifolds) {
      const vec = new Module.Vector_manifold;
      toVec(vec, manifolds);
      const result = Module._manifoldCompose(vec);
      vec.delete();
      return result
    };
    function manifoldBatchbool(name) {
      return function(...args) {
        if (args.length == 1) args = args[0];
        const v = new Module.Vector_manifold;
        for (const m of args) v.push_back(m);
        const result = Module['_manifold' + name + 'N'](v);
        v.delete();
        return result
      }
    }
    Module.Manifold.union = manifoldBatchbool('Union');
    Module.Manifold.difference = manifoldBatchbool('Difference');
    Module.Manifold.intersection = manifoldBatchbool('Intersection');
    Module.Manifold.levelSet = function(
        sdf, bounds, edgeLength, level = 0, tolerance = -1) {
      const bounds2 = {
        min: {x: bounds.min[0], y: bounds.min[1], z: bounds.min[2]},
        max: {x: bounds.max[0], y: bounds.max[1], z: bounds.max[2]}
      };
      const wasmFuncPtr = addFunction(function(vec3Ptr) {
        const x = getValue(vec3Ptr, 'double');
        const y = getValue(vec3Ptr + 8, 'double');
        const z = getValue(vec3Ptr + 16, 'double');
        const vert = [x, y, z];
        return sdf(vert)
      }, 'di');
      const out =
          Module._LevelSet(wasmFuncPtr, bounds2, edgeLength, level, tolerance);
      removeFunction(wasmFuncPtr);
      return out
    };
    function pushVec3(vec, ps) {
      toVec(vec, ps, p => {
        if (p instanceof Array) return {x: p[0], y: p[1], z: p[2]};
        return p
      })
    }
    Module.Manifold.hull = function(...args) {
      if (args.length == 1) args = args[0];
      let pts = new Module.Vector_vec3;
      for (const m of args) {
        if (m instanceof ManifoldCtor) {
          Module._manifoldCollectVertices(pts, m)
        } else if (
            m instanceof Array && m.length == 3 && typeof m[0] == 'number') {
          pts.push_back({x: m[0], y: m[1], z: m[2]})
        } else if (m.x) {
          pts.push_back(m)
        } else {
          pushVec3(pts, m)
        }
      }
      const result = Module._manifoldHullPoints(pts);
      pts.delete();
      return result
    };
    Module.Manifold.prototype = Object.create(ManifoldCtor.prototype);
    Object.defineProperty(
        Module.Manifold, Symbol.hasInstance,
        {get: () => t => t instanceof ManifoldCtor});
    Module.triangulate = function(polygons, epsilon = -1, allowConvex = true) {
      const polygonsVec = polygons2vec(polygons);
      const result = fromVec(
          Module._Triangulate(polygonsVec, epsilon, allowConvex),
          x => [x[0], x[1], x[2]]);
      disposePolygons(polygonsVec);
      return result
    }
  };
  var arguments_ = [];
  var thisProgram = './this.program';
  var quit_ = (status, toThrow) => {
    throw toThrow
  };
  var _scriptName = import.meta.url;
  var scriptDirectory = '';
  function locateFile(path) {
    if (Module['locateFile']) {
      return Module['locateFile'](path, scriptDirectory)
    }
    return scriptDirectory + path
  }
  var readAsync, readBinary;
  if (ENVIRONMENT_IS_NODE) {
    var fs = require('fs');
    if (_scriptName.startsWith('file:')) {
      scriptDirectory =
          require('path').dirname(require('url').fileURLToPath(_scriptName)) +
          '/'
    }
    readBinary = filename => {
      filename = isFileURI(filename) ? new URL(filename) : filename;
      var ret = fs.readFileSync(filename);
      return ret
    };
    readAsync = async (filename, binary = true) => {
      filename = isFileURI(filename) ? new URL(filename) : filename;
      var ret = fs.readFileSync(filename, binary ? undefined : 'utf8');
      return ret
    };
    if (process.argv.length > 1) {
      thisProgram = process.argv[1].replace(/\\/g, '/')
    }
    arguments_ = process.argv.slice(2);
    quit_ = (status, toThrow) => {
      process.exitCode = status;
      throw toThrow
    }
  } else if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
    try {
      scriptDirectory = new URL('.', _scriptName).href
    } catch {
    }
    {
      if (ENVIRONMENT_IS_WORKER) {
        readBinary = url => {
          var xhr = new XMLHttpRequest;
          xhr.open('GET', url, false);
          xhr.responseType = 'arraybuffer';
          xhr.send(null);
          return new Uint8Array(xhr.response)
        }
      }
      readAsync = async url => {
        if (isFileURI(url)) {
          return new Promise((resolve, reject) => {
            var xhr = new XMLHttpRequest;
            xhr.open('GET', url, true);
            xhr.responseType = 'arraybuffer';
            xhr.onload = () => {
              if (xhr.status == 200 || xhr.status == 0 && xhr.response) {
                resolve(xhr.response);
                return
              }
              reject(xhr.status)
            };
            xhr.onerror = reject;
            xhr.send(null)
          })
        }
        var response = await fetch(url, {credentials: 'same-origin'});
        if (response.ok) {
          return response.arrayBuffer()
        }
        throw new Error(response.status + ' : ' + response.url)
      }
    }
  } else {
  }
  var out = console.log.bind(console);
  var err = console.error.bind(console);
  var wasmBinary;
  var ABORT = false;
  var isFileURI = filename => filename.startsWith('file://');
  var readyPromiseResolve, readyPromiseReject;
  var wasmMemory;
  var HEAP8, HEAPU8, HEAP16, HEAPU16, HEAP32, HEAPU32, HEAPF32, HEAPF64;
  var HEAP64, HEAPU64;
  var runtimeInitialized = false;
  function updateMemoryViews() {
    var b = wasmMemory.buffer;
    HEAP8 = new Int8Array(b);
    HEAP16 = new Int16Array(b);
    HEAPU8 = new Uint8Array(b);
    HEAPU16 = new Uint16Array(b);
    HEAP32 = new Int32Array(b);
    HEAPU32 = new Uint32Array(b);
    HEAPF32 = new Float32Array(b);
    HEAPF64 = new Float64Array(b);
    HEAP64 = new BigInt64Array(b);
    HEAPU64 = new BigUint64Array(b)
  }
  function preRun() {
    if (Module['preRun']) {
      if (typeof Module['preRun'] == 'function')
        Module['preRun'] = [Module['preRun']];
      while (Module['preRun'].length) {
        addOnPreRun(Module['preRun'].shift())
      }
    }
    callRuntimeCallbacks(onPreRuns)
  }
  function initRuntime() {
    runtimeInitialized = true;
    wasmExports['H']()
  }
  function postRun() {
    if (Module['postRun']) {
      if (typeof Module['postRun'] == 'function')
        Module['postRun'] = [Module['postRun']];
      while (Module['postRun'].length) {
        addOnPostRun(Module['postRun'].shift())
      }
    }
    callRuntimeCallbacks(onPostRuns)
  }
  var runDependencies = 0;
  var dependenciesFulfilled = null;
  function addRunDependency(id) {
    runDependencies++;
    Module['monitorRunDependencies']?.(runDependencies)
  }
  function removeRunDependency(id) {
    runDependencies--;
    Module['monitorRunDependencies']?.(runDependencies);
    if (runDependencies == 0) {
      if (dependenciesFulfilled) {
        var callback = dependenciesFulfilled;
        dependenciesFulfilled = null;
        callback()
      }
    }
  }
  function abort(what) {
    Module['onAbort']?.(what);
    what = 'Aborted(' + what + ')';
    err(what);
    ABORT = true;
    what += '. Build with -sASSERTIONS for more info.';
    var e = new WebAssembly.RuntimeError(what);
    readyPromiseReject?.(e);
    throw e
  }
  var wasmBinaryFile;
  function findWasmBinary() {
    if (Module['locateFile']) {
      return locateFile('manifold.wasm')
    }
    return new URL('manifold.wasm', import.meta.url).href
  }
  function getBinarySync(file) {
    if (file == wasmBinaryFile && wasmBinary) {
      return new Uint8Array(wasmBinary)
    }
    if (readBinary) {
      return readBinary(file)
    }
    throw 'both async and sync fetching of the wasm failed'
  }
  async function getWasmBinary(binaryFile) {
    if (!wasmBinary) {
      try {
        var response = await readAsync(binaryFile);
        return new Uint8Array(response)
      } catch {
      }
    }
    return getBinarySync(binaryFile)
  }
  async function instantiateArrayBuffer(binaryFile, imports) {
    try {
      var binary = await getWasmBinary(binaryFile);
      var instance = await WebAssembly.instantiate(binary, imports);
      return instance
    } catch (reason) {
      err(`failed to asynchronously prepare wasm: ${reason}`);
      abort(reason)
    }
  }
  async function instantiateAsync(binary, binaryFile, imports) {
    if (!binary && !isFileURI(binaryFile) && !ENVIRONMENT_IS_NODE) {
      try {
        var response = fetch(binaryFile, {credentials: 'same-origin'});
        var instantiationResult =
            await WebAssembly.instantiateStreaming(response, imports);
        return instantiationResult
      } catch (reason) {
        err(`wasm streaming compile failed: ${reason}`);
        err('falling back to ArrayBuffer instantiation')
      }
    }
    return instantiateArrayBuffer(binaryFile, imports)
  }
  function getWasmImports() {
    return {
      a: wasmImports
    }
  }
  async function createWasm() {
    function receiveInstance(instance, module) {
      wasmExports = instance.exports;
      wasmExports = applySignatureConversions(wasmExports);
      wasmMemory = wasmExports['G'];
      updateMemoryViews();
      wasmTable = wasmExports['J'];
      assignWasmExports(wasmExports);
      removeRunDependency('wasm-instantiate');
      return wasmExports
    }
    addRunDependency('wasm-instantiate');
    function receiveInstantiationResult(result) {
      return receiveInstance(result['instance'])
    }
    var info = getWasmImports();
    if (Module['instantiateWasm']) {
      return new Promise(
          (resolve, reject) => {Module['instantiateWasm'](
              info, (mod, inst) => {resolve(receiveInstance(mod, inst))})})
    }
    wasmBinaryFile ??= findWasmBinary();
    var result = await instantiateAsync(wasmBinary, wasmBinaryFile, info);
    var exports = receiveInstantiationResult(result);
    return exports
  }
  class ExitStatus {
    name = 'ExitStatus';
    constructor(status) {
      this.message = `Program terminated with exit(${status})`;
      this.status = status
    }
  }
  var callRuntimeCallbacks = callbacks => {
    while (callbacks.length > 0) {
      callbacks.shift()(Module)
    }
  };
  var onPostRuns = [];
  var addOnPostRun = cb => onPostRuns.push(cb);
  var onPreRuns = [];
  var addOnPreRun = cb => onPreRuns.push(cb);
  function getValue(ptr, type = 'i8') {
    if (type.endsWith('*')) type = '*';
    switch (type) {
      case 'i1':
        return HEAP8[ptr >>> 0];
      case 'i8':
        return HEAP8[ptr >>> 0];
      case 'i16':
        return HEAP16[ptr >>> 1 >>> 0];
      case 'i32':
        return HEAP32[ptr >>> 2 >>> 0];
      case 'i64':
        return HEAP64[ptr >>> 3 >>> 0];
      case 'float':
        return HEAPF32[ptr >>> 2 >>> 0];
      case 'double':
        return HEAPF64[ptr >>> 3 >>> 0];
      case '*':
        return HEAPU32[ptr >>> 2 >>> 0];
      default:
        abort(`invalid type for getValue: ${type}`)
    }
  }
  var noExitRuntime = true;
  function setValue(ptr, value, type = 'i8') {
    if (type.endsWith('*')) type = '*';
    switch (type) {
      case 'i1':
        HEAP8[ptr >>> 0] = value;
        break;
      case 'i8':
        HEAP8[ptr >>> 0] = value;
        break;
      case 'i16':
        HEAP16[ptr >>> 1 >>> 0] = value;
        break;
      case 'i32':
        HEAP32[ptr >>> 2 >>> 0] = value;
        break;
      case 'i64':
        HEAP64[ptr >>> 3 >>> 0] = BigInt(value);
        break;
      case 'float':
        HEAPF32[ptr >>> 2 >>> 0] = value;
        break;
      case 'double':
        HEAPF64[ptr >>> 3 >>> 0] = value;
        break;
      case '*':
        HEAPU32[ptr >>> 2 >>> 0] = value;
        break;
      default:
        abort(`invalid type for setValue: ${type}`)
    }
  }
  class ExceptionInfo {
    constructor(excPtr) {
      this.excPtr = excPtr;
      this.ptr = excPtr - 24
    }
    set_type(type) {
      HEAPU32[this.ptr + 4 >>> 2 >>> 0] = type
    }
    get_type() {
      return HEAPU32[this.ptr + 4 >>> 2 >>> 0]
    }
    set_destructor(destructor) {
      HEAPU32[this.ptr + 8 >>> 2 >>> 0] = destructor
    }
    get_destructor() {
      return HEAPU32[this.ptr + 8 >>> 2 >>> 0]
    }
    set_caught(caught) {
      caught = caught ? 1 : 0;
      HEAP8[this.ptr + 12 >>> 0] = caught
    }
    get_caught() {
      return HEAP8[this.ptr + 12 >>> 0] != 0
    }
    set_rethrown(rethrown) {
      rethrown = rethrown ? 1 : 0;
      HEAP8[this.ptr + 13 >>> 0] = rethrown
    }
    get_rethrown() {
      return HEAP8[this.ptr + 13 >>> 0] != 0
    }
    init(type, destructor) {
      this.set_adjusted_ptr(0);
      this.set_type(type);
      this.set_destructor(destructor)
    }
    set_adjusted_ptr(adjustedPtr) {
      HEAPU32[this.ptr + 16 >>> 2 >>> 0] = adjustedPtr
    }
    get_adjusted_ptr() {
      return HEAPU32[this.ptr + 16 >>> 2 >>> 0]
    }
  }
  var exceptionLast = 0;
  var uncaughtExceptionCount = 0;
  function ___cxa_throw(ptr, type, destructor) {
    ptr >>>= 0;
    type >>>= 0;
    destructor >>>= 0;
    var info = new ExceptionInfo(ptr);
    info.init(type, destructor);
    exceptionLast = ptr;
    uncaughtExceptionCount++;
    throw exceptionLast
  }
  var __abort_js = () => abort('');
  var structRegistrations = {};
  var runDestructors = destructors => {
    while (destructors.length) {
      var ptr = destructors.pop();
      var del = destructors.pop();
      del(ptr)
    }
  };
  function readPointer(pointer) {
    return this.fromWireType(HEAPU32[pointer >>> 2 >>> 0])
  }
  var awaitingDependencies = {};
  var registeredTypes = {};
  var typeDependencies = {};
  var InternalError = class InternalError extends Error {
    constructor(message) {
      super(message);
      this.name = 'InternalError'
    }
  };
  var throwInternalError = message => {
    throw new InternalError(message)
  };
  var whenDependentTypesAreResolved =
      (myTypes, dependentTypes, getTypeConverters) => {
        myTypes.forEach(type => typeDependencies[type] = dependentTypes);
        function onComplete(typeConverters) {
          var myTypeConverters = getTypeConverters(typeConverters);
          if (myTypeConverters.length !== myTypes.length) {
            throwInternalError('Mismatched type converter count')
          }
          for (var i = 0; i < myTypes.length; ++i) {
            registerType(myTypes[i], myTypeConverters[i])
          }
        }
        var typeConverters = new Array(dependentTypes.length);
        var unregisteredTypes = [];
        var registered = 0;
        dependentTypes.forEach((dt, i) => {
          if (registeredTypes.hasOwnProperty(dt)) {
            typeConverters[i] = registeredTypes[dt]
          } else {
            unregisteredTypes.push(dt);
            if (!awaitingDependencies.hasOwnProperty(dt)) {
              awaitingDependencies[dt] = []
            }
            awaitingDependencies[dt].push(() => {
              typeConverters[i] = registeredTypes[dt];
              ++registered;
              if (registered === unregisteredTypes.length) {
                onComplete(typeConverters)
              }
            })
          }
        });
        if (0 === unregisteredTypes.length) {
          onComplete(typeConverters)
        }
      };
  var __embind_finalize_value_object = function(structType) {
    structType >>>= 0;
    var reg = structRegistrations[structType];
    delete structRegistrations[structType];
    var rawConstructor = reg.rawConstructor;
    var rawDestructor = reg.rawDestructor;
    var fieldRecords = reg.fields;
    var fieldTypes =
        fieldRecords.map(field => field.getterReturnType)
            .concat(fieldRecords.map(field => field.setterArgumentType));
    whenDependentTypesAreResolved([structType], fieldTypes, fieldTypes => {
      var fields = {};
      fieldRecords.forEach((field, i) => {
        var fieldName = field.fieldName;
        var getterReturnType = fieldTypes[i];
        var optional = fieldTypes[i].optional;
        var getter = field.getter;
        var getterContext = field.getterContext;
        var setterArgumentType = fieldTypes[i + fieldRecords.length];
        var setter = field.setter;
        var setterContext = field.setterContext;
        fields[fieldName] = {
          read: ptr =>
              getterReturnType.fromWireType(getter(getterContext, ptr)),
          write: (ptr, o) => {
            var destructors = [];
            setter(
                setterContext, ptr,
                setterArgumentType.toWireType(destructors, o));
            runDestructors(destructors)
          },
          optional
        }
      });
      return [{
        name: reg.name,
        fromWireType: ptr => {
          var rv = {};
          for (var i in fields) {
            rv[i] = fields[i].read(ptr)
          }
          rawDestructor(ptr);
          return rv
        },
        toWireType: (destructors, o) => {
          for (var fieldName in fields) {
            if (!(fieldName in o) && !fields[fieldName].optional) {
              throw new TypeError(`Missing field: "${fieldName}"`)
            }
          }
          var ptr = rawConstructor();
          for (fieldName in fields) {
            fields[fieldName].write(ptr, o[fieldName])
          }
          if (destructors !== null) {
            destructors.push(rawDestructor, ptr)
          }
          return ptr
        },
        readValueFromPointer: readPointer,
        destructorFunction: rawDestructor
      }]
    })
  };
  var AsciiToString = ptr => {
    ptr >>>= 0;
    var str = '';
    while (1) {
      var ch = HEAPU8[ptr++ >>> 0];
      if (!ch) return str;
      str += String.fromCharCode(ch)
    }
  };
  var BindingError = class BindingError extends Error {
    constructor(message) {
      super(message);
      this.name = 'BindingError'
    }
  };
  var throwBindingError = message => {
    throw new BindingError(message)
  };
  function sharedRegisterType(rawType, registeredInstance, options = {}) {
    var name = registeredInstance.name;
    if (!rawType) {
      throwBindingError(
          `type "${name}" must have a positive integer typeid pointer`)
    }
    if (registeredTypes.hasOwnProperty(rawType)) {
      if (options.ignoreDuplicateRegistrations) {
        return
      } else {
        throwBindingError(`Cannot register type '${name}' twice`)
      }
    }
    registeredTypes[rawType] = registeredInstance;
    delete typeDependencies[rawType];
    if (awaitingDependencies.hasOwnProperty(rawType)) {
      var callbacks = awaitingDependencies[rawType];
      delete awaitingDependencies[rawType];
      callbacks.forEach(cb => cb())
    }
  }
  function registerType(rawType, registeredInstance, options = {}) {
    return sharedRegisterType(rawType, registeredInstance, options)
  }
  var integerReadValueFromPointer = (name, width, signed) => {
    switch (width) {
      case 1:
        return signed ? pointer => HEAP8[pointer >>> 0] :
                        pointer => HEAPU8[pointer >>> 0];
      case 2:
        return signed ? pointer => HEAP16[pointer >>> 1 >>> 0] :
                        pointer => HEAPU16[pointer >>> 1 >>> 0];
      case 4:
        return signed ? pointer => HEAP32[pointer >>> 2 >>> 0] :
                        pointer => HEAPU32[pointer >>> 2 >>> 0];
      case 8:
        return signed ? pointer => HEAP64[pointer >>> 3 >>> 0] :
                        pointer => HEAPU64[pointer >>> 3 >>> 0];
      default:
        throw new TypeError(`invalid integer width (${width}): ${name}`)
    }
  };
  var __embind_register_bigint = function(
      primitiveType, name, size, minRange, maxRange) {
    primitiveType >>>= 0;
    name >>>= 0;
    size >>>= 0;
    name = AsciiToString(name);
    const isUnsignedType = minRange === 0n;
    let fromWireType = value => value;
    if (isUnsignedType) {
      const bitSize = size * 8;
      fromWireType = value => BigInt.asUintN(bitSize, value);
      maxRange = fromWireType(maxRange)
    }
    registerType(primitiveType, {
      name,
      fromWireType,
      toWireType: (destructors, value) => {
        if (typeof value == 'number') {
          value = BigInt(value)
        }
        return value
      },
      readValueFromPointer:
          integerReadValueFromPointer(name, size, !isUnsignedType),
      destructorFunction: null
    })
  };
  function __embind_register_bool(rawType, name, trueValue, falseValue) {
    rawType >>>= 0;
    name >>>= 0;
    name = AsciiToString(name);
    registerType(rawType, {
      name,
      fromWireType: function(wt) {
        return !!wt
      },
      toWireType: function(destructors, o) {
        return o ? trueValue : falseValue
      },
      readValueFromPointer: function(pointer) {
        return this.fromWireType(HEAPU8[pointer >>> 0])
      },
      destructorFunction: null
    })
  }
  var shallowCopyInternalPointer = o => ({
    count: o.count,
    deleteScheduled: o.deleteScheduled,
    preservePointerOnDelete: o.preservePointerOnDelete,
    ptr: o.ptr,
    ptrType: o.ptrType,
    smartPtr: o.smartPtr,
    smartPtrType: o.smartPtrType
  });
  var throwInstanceAlreadyDeleted = obj => {
    function getInstanceTypeName(handle) {
      return handle.$$.ptrType.registeredClass.name
    }
    throwBindingError(getInstanceTypeName(obj) + ' instance already deleted')
  };
  var finalizationRegistry = false;
  var detachFinalizer = handle => {};
  var runDestructor = $$ => {
    if ($$.smartPtr) {
      $$.smartPtrType.rawDestructor($$.smartPtr)
    } else {
      $$.ptrType.registeredClass.rawDestructor($$.ptr)
    }
  };
  var releaseClassHandle = $$ => {
    $$.count.value -= 1;
    var toDelete = 0 === $$.count.value;
    if (toDelete) {
      runDestructor($$)
    }
  };
  var attachFinalizer = handle => {
    if ('undefined' === typeof FinalizationRegistry) {
      attachFinalizer = handle => handle;
      return handle
    }
    finalizationRegistry =
        new FinalizationRegistry(info => {releaseClassHandle(info.$$)});
    attachFinalizer = handle => {
      var $$ = handle.$$;
      var hasSmartPtr = !!$$.smartPtr;
      if (hasSmartPtr) {
        var info = {$$};
        finalizationRegistry.register(handle, info, handle)
      }
      return handle
    };
    detachFinalizer = handle => finalizationRegistry.unregister(handle);
    return attachFinalizer(handle)
  };
  var deletionQueue = [];
  var flushPendingDeletes = () => {
    while (deletionQueue.length) {
      var obj = deletionQueue.pop();
      obj.$$.deleteScheduled = false;
      obj['delete']()
    }
  };
  var delayFunction;
  var init_ClassHandle = () => {
    let proto = ClassHandle.prototype;
    Object.assign(proto, {
      isAliasOf(other) {
        if (!(this instanceof ClassHandle)) {
          return false
        }
        if (!(other instanceof ClassHandle)) {
          return false
        }
        var leftClass = this.$$.ptrType.registeredClass;
        var left = this.$$.ptr;
        other.$$ = other.$$;
        var rightClass = other.$$.ptrType.registeredClass;
        var right = other.$$.ptr;
        while (leftClass.baseClass) {
          left = leftClass.upcast(left);
          leftClass = leftClass.baseClass
        }
        while (rightClass.baseClass) {
          right = rightClass.upcast(right);
          rightClass = rightClass.baseClass
        }
        return leftClass === rightClass && left === right
      },
      clone() {
        if (!this.$$.ptr) {
          throwInstanceAlreadyDeleted(this)
        }
        if (this.$$.preservePointerOnDelete) {
          this.$$.count.value += 1;
          return this
        } else {
          var clone = attachFinalizer(Object.create(
              Object.getPrototypeOf(this),
              {$$: {value: shallowCopyInternalPointer(this.$$)}}));
          clone.$$.count.value += 1;
          clone.$$.deleteScheduled = false;
          return clone
        }
      },
      delete () {
        if (!this.$$.ptr) {
          throwInstanceAlreadyDeleted(this)
        }
        if (this.$$.deleteScheduled && !this.$$.preservePointerOnDelete) {
          throwBindingError('Object already scheduled for deletion')
        }
        detachFinalizer(this);
        releaseClassHandle(this.$$);
        if (!this.$$.preservePointerOnDelete) {
          this.$$.smartPtr = undefined;
          this.$$.ptr = undefined
        }
      },
      isDeleted() {
        return !this.$$.ptr
      },
      deleteLater() {
        if (!this.$$.ptr) {
          throwInstanceAlreadyDeleted(this)
        }
        if (this.$$.deleteScheduled && !this.$$.preservePointerOnDelete) {
          throwBindingError('Object already scheduled for deletion')
        }
        deletionQueue.push(this);
        if (deletionQueue.length === 1 && delayFunction) {
          delayFunction(flushPendingDeletes)
        }
        this.$$.deleteScheduled = true;
        return this
      }
    });
    const symbolDispose = Symbol.dispose;
    if (symbolDispose) {
      proto[symbolDispose] = proto['delete']
    }
  };
  function ClassHandle() {}
  var createNamedFunction = (name, func) =>
      Object.defineProperty(func, 'name', {value: name});
  var registeredPointers = {};
  var ensureOverloadTable = (proto, methodName, humanName) => {
    if (undefined === proto[methodName].overloadTable) {
      var prevFunc = proto[methodName];
      proto[methodName] = function(...args) {
        if (!proto[methodName].overloadTable.hasOwnProperty(args.length)) {
          throwBindingError(`Function '${
              humanName}' called with an invalid number of arguments (${
              args.length}) - expects one of (${
              proto[methodName].overloadTable})!`)
        }
        return proto[methodName].overloadTable[args.length].apply(this, args)
      };
      proto[methodName].overloadTable = [];
      proto[methodName].overloadTable[prevFunc.argCount] = prevFunc
    }
  };
  var exposePublicSymbol = (name, value, numArguments) => {
    if (Module.hasOwnProperty(name)) {
      if (undefined === numArguments ||
          undefined !== Module[name].overloadTable &&
              undefined !== Module[name].overloadTable[numArguments]) {
        throwBindingError(`Cannot register public name '${name}' twice`)
      }
      ensureOverloadTable(Module, name, name);
      if (Module[name].overloadTable.hasOwnProperty(numArguments)) {
        throwBindingError(
            `Cannot register multiple overloads of a function with the same number of arguments (${
                numArguments})!`)
      }
      Module[name].overloadTable[numArguments] = value
    } else {
      Module[name] = value;
      Module[name].argCount = numArguments
    }
  };
  var char_0 = 48;
  var char_9 = 57;
  var makeLegalFunctionName = name => {
    name = name.replace(/[^a-zA-Z0-9_]/g, '$');
    var f = name.charCodeAt(0);
    if (f >= char_0 && f <= char_9) {
      return `_${name}`
    }
    return name
  };
  function RegisteredClass(
      name, constructor, instancePrototype, rawDestructor, baseClass,
      getActualType, upcast, downcast) {
    this.name = name;
    this.constructor = constructor;
    this.instancePrototype = instancePrototype;
    this.rawDestructor = rawDestructor;
    this.baseClass = baseClass;
    this.getActualType = getActualType;
    this.upcast = upcast;
    this.downcast = downcast;
    this.pureVirtualFunctions = []
  }
  var upcastPointer = (ptr, ptrClass, desiredClass) => {
    while (ptrClass !== desiredClass) {
      if (!ptrClass.upcast) {
        throwBindingError(`Expected null or instance of ${
            desiredClass.name}, got an instance of ${ptrClass.name}`)
      }
      ptr = ptrClass.upcast(ptr);
      ptrClass = ptrClass.baseClass
    }
    return ptr
  };
  var embindRepr = v => {
    if (v === null) {
      return 'null'
    }
    var t = typeof v;
    if (t === 'object' || t === 'array' || t === 'function') {
      return v.toString()
    } else {
      return '' + v
    }
  };
  function constNoSmartPtrRawPointerToWireType(destructors, handle) {
    if (handle === null) {
      if (this.isReference) {
        throwBindingError(`null is not a valid ${this.name}`)
      }
      return 0
    }
    if (!handle.$$) {
      throwBindingError(`Cannot pass "${embindRepr(handle)}" as a ${this.name}`)
    }
    if (!handle.$$.ptr) {
      throwBindingError(
          `Cannot pass deleted object as a pointer of type ${this.name}`)
    }
    var handleClass = handle.$$.ptrType.registeredClass;
    var ptr = upcastPointer(handle.$$.ptr, handleClass, this.registeredClass);
    return ptr
  }
  function genericPointerToWireType(destructors, handle) {
    var ptr;
    if (handle === null) {
      if (this.isReference) {
        throwBindingError(`null is not a valid ${this.name}`)
      }
      if (this.isSmartPointer) {
        ptr = this.rawConstructor();
        if (destructors !== null) {
          destructors.push(this.rawDestructor, ptr)
        }
        return ptr
      } else {
        return 0
      }
    }
    if (!handle || !handle.$$) {
      throwBindingError(`Cannot pass "${embindRepr(handle)}" as a ${this.name}`)
    }
    if (!handle.$$.ptr) {
      throwBindingError(
          `Cannot pass deleted object as a pointer of type ${this.name}`)
    }
    if (!this.isConst && handle.$$.ptrType.isConst) {
      throwBindingError(`Cannot convert argument of type ${
          handle.$$.smartPtrType ?
              handle.$$.smartPtrType.name :
              handle.$$.ptrType.name} to parameter type ${this.name}`)
    }
    var handleClass = handle.$$.ptrType.registeredClass;
    ptr = upcastPointer(handle.$$.ptr, handleClass, this.registeredClass);
    if (this.isSmartPointer) {
      if (undefined === handle.$$.smartPtr) {
        throwBindingError('Passing raw pointer to smart pointer is illegal')
      }
      switch (this.sharingPolicy) {
        case 0:
          if (handle.$$.smartPtrType === this) {
            ptr = handle.$$.smartPtr
          } else {
            throwBindingError(`Cannot convert argument of type ${
                handle.$$.smartPtrType ?
                    handle.$$.smartPtrType.name :
                    handle.$$.ptrType.name} to parameter type ${this.name}`)
          }
          break;
        case 1:
          ptr = handle.$$.smartPtr;
          break;
        case 2:
          if (handle.$$.smartPtrType === this) {
            ptr = handle.$$.smartPtr
          } else {
            var clonedHandle = handle['clone']();
            ptr = this.rawShare(
                ptr, Emval.toHandle(() => clonedHandle['delete']()));
            if (destructors !== null) {
              destructors.push(this.rawDestructor, ptr)
            }
          }
          break;
        default:
          throwBindingError('Unsupporting sharing policy')
      }
    }
    return ptr
  }
  function nonConstNoSmartPtrRawPointerToWireType(destructors, handle) {
    if (handle === null) {
      if (this.isReference) {
        throwBindingError(`null is not a valid ${this.name}`)
      }
      return 0
    }
    if (!handle.$$) {
      throwBindingError(`Cannot pass "${embindRepr(handle)}" as a ${this.name}`)
    }
    if (!handle.$$.ptr) {
      throwBindingError(
          `Cannot pass deleted object as a pointer of type ${this.name}`)
    }
    if (handle.$$.ptrType.isConst) {
      throwBindingError(`Cannot convert argument of type ${
          handle.$$.ptrType.name} to parameter type ${this.name}`)
    }
    var handleClass = handle.$$.ptrType.registeredClass;
    var ptr = upcastPointer(handle.$$.ptr, handleClass, this.registeredClass);
    return ptr
  }
  var downcastPointer = (ptr, ptrClass, desiredClass) => {
    if (ptrClass === desiredClass) {
      return ptr
    }
    if (undefined === desiredClass.baseClass) {
      return null
    }
    var rv = downcastPointer(ptr, ptrClass, desiredClass.baseClass);
    if (rv === null) {
      return null
    }
    return desiredClass.downcast(rv)
  };
  var registeredInstances = {};
  var getBasestPointer = (class_, ptr) => {
    if (ptr === undefined) {
      throwBindingError('ptr should not be undefined')
    }
    while (class_.baseClass) {
      ptr = class_.upcast(ptr);
      class_ = class_.baseClass
    }
    return ptr
  };
  var getInheritedInstance = (class_, ptr) => {
    ptr = getBasestPointer(class_, ptr);
    return registeredInstances[ptr]
  };
  var makeClassHandle = (prototype, record) => {
    if (!record.ptrType || !record.ptr) {
      throwInternalError('makeClassHandle requires ptr and ptrType')
    }
    var hasSmartPtrType = !!record.smartPtrType;
    var hasSmartPtr = !!record.smartPtr;
    if (hasSmartPtrType !== hasSmartPtr) {
      throwInternalError('Both smartPtrType and smartPtr must be specified')
    }
    record.count = {value: 1};
    return attachFinalizer(
        Object.create(prototype, {$$: {value: record, writable: true}}))
  };
  function RegisteredPointer_fromWireType(ptr) {
    var rawPointer = this.getPointee(ptr);
    if (!rawPointer) {
      this.destructor(ptr);
      return null
    }
    var registeredInstance =
        getInheritedInstance(this.registeredClass, rawPointer);
    if (undefined !== registeredInstance) {
      if (0 === registeredInstance.$$.count.value) {
        registeredInstance.$$.ptr = rawPointer;
        registeredInstance.$$.smartPtr = ptr;
        return registeredInstance['clone']()
      } else {
        var rv = registeredInstance['clone']();
        this.destructor(ptr);
        return rv
      }
    }
    function makeDefaultHandle() {
      if (this.isSmartPointer) {
        return makeClassHandle(this.registeredClass.instancePrototype, {
          ptrType: this.pointeeType,
          ptr: rawPointer,
          smartPtrType: this,
          smartPtr: ptr
        })
      } else {
        return makeClassHandle(
            this.registeredClass.instancePrototype, {ptrType: this, ptr})
      }
    }
    var actualType = this.registeredClass.getActualType(rawPointer);
    var registeredPointerRecord = registeredPointers[actualType];
    if (!registeredPointerRecord) {
      return makeDefaultHandle.call(this)
    }
    var toType;
    if (this.isConst) {
      toType = registeredPointerRecord.constPointerType
    } else {
      toType = registeredPointerRecord.pointerType
    }
    var dp = downcastPointer(
        rawPointer, this.registeredClass, toType.registeredClass);
    if (dp === null) {
      return makeDefaultHandle.call(this)
    }
    if (this.isSmartPointer) {
      return makeClassHandle(
          toType.registeredClass.instancePrototype,
          {ptrType: toType, ptr: dp, smartPtrType: this, smartPtr: ptr})
    } else {
      return makeClassHandle(
          toType.registeredClass.instancePrototype, {ptrType: toType, ptr: dp})
    }
  }
  var init_RegisteredPointer = () => {
    Object.assign(RegisteredPointer.prototype, {
      getPointee(ptr) {
        if (this.rawGetPointee) {
          ptr = this.rawGetPointee(ptr)
        }
        return ptr
      },
      destructor(ptr) {
        this.rawDestructor?.(ptr)
      },
      readValueFromPointer: readPointer,
      fromWireType: RegisteredPointer_fromWireType
    })
  };
  function RegisteredPointer(
      name, registeredClass, isReference, isConst, isSmartPointer, pointeeType,
      sharingPolicy, rawGetPointee, rawConstructor, rawShare, rawDestructor) {
    this.name = name;
    this.registeredClass = registeredClass;
    this.isReference = isReference;
    this.isConst = isConst;
    this.isSmartPointer = isSmartPointer;
    this.pointeeType = pointeeType;
    this.sharingPolicy = sharingPolicy;
    this.rawGetPointee = rawGetPointee;
    this.rawConstructor = rawConstructor;
    this.rawShare = rawShare;
    this.rawDestructor = rawDestructor;
    if (!isSmartPointer && registeredClass.baseClass === undefined) {
      if (isConst) {
        this.toWireType = constNoSmartPtrRawPointerToWireType;
        this.destructorFunction = null
      } else {
        this.toWireType = nonConstNoSmartPtrRawPointerToWireType;
        this.destructorFunction = null
      }
    } else {
      this.toWireType = genericPointerToWireType
    }
  }
  var replacePublicSymbol = (name, value, numArguments) => {
    if (!Module.hasOwnProperty(name)) {
      throwInternalError('Replacing nonexistent public symbol')
    }
    if (undefined !== Module[name].overloadTable &&
        undefined !== numArguments) {
      Module[name].overloadTable[numArguments] = value
    } else {
      Module[name] = value;
      Module[name].argCount = numArguments
    }
  };
  var wasmTable;
  var getWasmTableEntry = funcPtr => wasmTable.get(funcPtr);
  var dynCall = (sig, ptr, args = [], promising = false) => {
    var func = getWasmTableEntry(ptr);
    var rtn = func(...args);
    function convert(rtn) {
      return sig[0] == 'p' ? rtn >>> 0 : rtn
    }
    return convert(rtn)
  };
  var getDynCaller = (sig, ptr, promising = false) => (...args) =>
      dynCall(sig, ptr, args, promising);
  var embind__requireFunction = (signature, rawFunction, isAsync = false) => {
    signature = AsciiToString(signature);
    function makeDynCaller() {
      if (signature.includes('p')) {
        return getDynCaller(signature, rawFunction, isAsync)
      }
      var rtn = getWasmTableEntry(rawFunction);
      return rtn
    }
    var fp = makeDynCaller();
    if (typeof fp != 'function') {
      throwBindingError(`unknown function pointer with signature ${
          signature}: ${rawFunction}`)
    }
    return fp
  };
  class UnboundTypeError extends Error {}
  var getTypeName = type => {
    var ptr = ___getTypeName(type);
    var rv = AsciiToString(ptr);
    _free(ptr);
    return rv
  };
  var throwUnboundTypeError = (message, types) => {
    var unboundTypes = [];
    var seen = {};
    function visit(type) {
      if (seen[type]) {
        return
      }
      if (registeredTypes[type]) {
        return
      }
      if (typeDependencies[type]) {
        typeDependencies[type].forEach(visit);
        return
      }
      unboundTypes.push(type);
      seen[type] = true
    }
    types.forEach(visit);
    throw new UnboundTypeError(
        `${message}: ` + unboundTypes.map(getTypeName).join([', ']))
  };
  function __embind_register_class(
      rawType, rawPointerType, rawConstPointerType, baseClassRawType,
      getActualTypeSignature, getActualType, upcastSignature, upcast,
      downcastSignature, downcast, name, destructorSignature, rawDestructor) {
    rawType >>>= 0;
    rawPointerType >>>= 0;
    rawConstPointerType >>>= 0;
    baseClassRawType >>>= 0;
    getActualTypeSignature >>>= 0;
    getActualType >>>= 0;
    upcastSignature >>>= 0;
    upcast >>>= 0;
    downcastSignature >>>= 0;
    downcast >>>= 0;
    name >>>= 0;
    destructorSignature >>>= 0;
    rawDestructor >>>= 0;
    name = AsciiToString(name);
    getActualType =
        embind__requireFunction(getActualTypeSignature, getActualType);
    upcast &&= embind__requireFunction(upcastSignature, upcast);
    downcast &&= embind__requireFunction(downcastSignature, downcast);
    rawDestructor = embind__requireFunction(destructorSignature, rawDestructor);
    var legalFunctionName = makeLegalFunctionName(name);
    exposePublicSymbol(legalFunctionName, function() {
      throwUnboundTypeError(
          `Cannot construct ${name} due to unbound types`, [baseClassRawType])
    });
    whenDependentTypesAreResolved(
        [rawType, rawPointerType, rawConstPointerType],
        baseClassRawType ? [baseClassRawType] : [], base => {
          base = base[0];
          var baseClass;
          var basePrototype;
          if (baseClassRawType) {
            baseClass = base.registeredClass;
            basePrototype = baseClass.instancePrototype
          } else {
            basePrototype = ClassHandle.prototype
          }
          var constructor = createNamedFunction(name, function(...args) {
            if (Object.getPrototypeOf(this) !== instancePrototype) {
              throw new BindingError(`Use 'new' to construct ${name}`)
            }
            if (undefined === registeredClass.constructor_body) {
              throw new BindingError(`${name} has no accessible constructor`)
            }
            var body = registeredClass.constructor_body[args.length];
            if (undefined === body) {
              throw new BindingError(`Tried to invoke ctor of ${
                  name} with invalid number of parameters (${
                  args.length}) - expected (${
                  Object.keys(registeredClass.constructor_body)
                      .toString()}) parameters instead!`)
            }
            return body.apply(this, args)
          });
          var instancePrototype =
              Object.create(basePrototype, {constructor: {value: constructor}});
          constructor.prototype = instancePrototype;
          var registeredClass = new RegisteredClass(
              name, constructor, instancePrototype, rawDestructor, baseClass,
              getActualType, upcast, downcast);
          if (registeredClass.baseClass) {
            registeredClass.baseClass.__derivedClasses ??= [];
            registeredClass.baseClass.__derivedClasses.push(registeredClass)
          }
          var referenceConverter =
              new RegisteredPointer(name, registeredClass, true, false, false);
          var pointerConverter = new RegisteredPointer(
              name + '*', registeredClass, false, false, false);
          var constPointerConverter = new RegisteredPointer(
              name + ' const*', registeredClass, false, true, false);
          registeredPointers[rawType] = {
            pointerType: pointerConverter,
            constPointerType: constPointerConverter
          };
          replacePublicSymbol(legalFunctionName, constructor);
          return [referenceConverter, pointerConverter, constPointerConverter]
        })
  }
  var heap32VectorToArray = (count, firstElement) => {
    var array = [];
    for (var i = 0; i < count; i++) {
      array.push(HEAPU32[firstElement + i * 4 >>> 2 >>> 0])
    }
    return array
  };
  function usesDestructorStack(argTypes) {
    for (var i = 1; i < argTypes.length; ++i) {
      if (argTypes[i] !== null &&
          argTypes[i].destructorFunction === undefined) {
        return true
      }
    }
    return false
  }
  function createJsInvoker(argTypes, isClassMethodFunc, returns, isAsync) {
    var needsDestructorStack = usesDestructorStack(argTypes);
    var argCount = argTypes.length - 2;
    var argsList = [];
    var argsListWired = ['fn'];
    if (isClassMethodFunc) {
      argsListWired.push('thisWired')
    }
    for (var i = 0; i < argCount; ++i) {
      argsList.push(`arg${i}`);
      argsListWired.push(`arg${i}Wired`)
    }
    argsList = argsList.join(',');
    argsListWired = argsListWired.join(',');
    var invokerFnBody = `return function (${argsList}) {\n`;
    if (needsDestructorStack) {
      invokerFnBody += 'var destructors = [];\n'
    }
    var dtorStack = needsDestructorStack ? 'destructors' : 'null';
    var args1 = [
      'humanName', 'throwBindingError', 'invoker', 'fn', 'runDestructors',
      'fromRetWire', 'toClassParamWire'
    ];
    if (isClassMethodFunc) {
      invokerFnBody += `var thisWired = toClassParamWire(${dtorStack}, this);\n`
    }
    for (var i = 0; i < argCount; ++i) {
      var argName = `toArg${i}Wire`;
      invokerFnBody +=
          `var arg${i}Wired = ${argName}(${dtorStack}, arg${i});\n`;
      args1.push(argName)
    }
    invokerFnBody += (returns || isAsync ? 'var rv = ' : '') +
        `invoker(${argsListWired});\n`;
    if (needsDestructorStack) {
      invokerFnBody += 'runDestructors(destructors);\n'
    } else {
      for (var i = isClassMethodFunc ? 1 : 2; i < argTypes.length; ++i) {
        var paramName = i === 1 ? 'thisWired' : 'arg' + (i - 2) + 'Wired';
        if (argTypes[i].destructorFunction !== null) {
          invokerFnBody += `${paramName}_dtor(${paramName});\n`;
          args1.push(`${paramName}_dtor`)
        }
      }
    }
    if (returns) {
      invokerFnBody += 'var ret = fromRetWire(rv);\n' +
          'return ret;\n'
    } else {
    }
    invokerFnBody += '}\n';
    return new Function(args1, invokerFnBody)
  }
  function craftInvokerFunction(
      humanName, argTypes, classType, cppInvokerFunc, cppTargetFunc, isAsync) {
    var argCount = argTypes.length;
    if (argCount < 2) {
      throwBindingError(
          'argTypes array size mismatch! Must at least get return value and \'this\' types!')
    }
    var isClassMethodFunc = argTypes[1] !== null && classType !== null;
    var needsDestructorStack = usesDestructorStack(argTypes);
    var returns = !argTypes[0].isVoid;
    var retType = argTypes[0];
    var instType = argTypes[1];
    var closureArgs = [
      humanName, throwBindingError, cppInvokerFunc, cppTargetFunc,
      runDestructors, retType.fromWireType.bind(retType),
      instType?.toWireType.bind(instType)
    ];
    for (var i = 2; i < argCount; ++i) {
      var argType = argTypes[i];
      closureArgs.push(argType.toWireType.bind(argType))
    }
    if (!needsDestructorStack) {
      for (var i = isClassMethodFunc ? 1 : 2; i < argTypes.length; ++i) {
        if (argTypes[i].destructorFunction !== null) {
          closureArgs.push(argTypes[i].destructorFunction)
        }
      }
    }
    let invokerFactory =
        createJsInvoker(argTypes, isClassMethodFunc, returns, isAsync);
    var invokerFn = invokerFactory(...closureArgs);
    return createNamedFunction(humanName, invokerFn)
  }
  var __embind_register_class_constructor = function(
      rawClassType, argCount, rawArgTypesAddr, invokerSignature, invoker,
      rawConstructor) {
    rawClassType >>>= 0;
    rawArgTypesAddr >>>= 0;
    invokerSignature >>>= 0;
    invoker >>>= 0;
    rawConstructor >>>= 0;
    var rawArgTypes = heap32VectorToArray(argCount, rawArgTypesAddr);
    invoker = embind__requireFunction(invokerSignature, invoker);
    whenDependentTypesAreResolved([], [rawClassType], classType => {
      classType = classType[0];
      var humanName = `constructor ${classType.name}`;
      if (undefined === classType.registeredClass.constructor_body) {
        classType.registeredClass.constructor_body = []
      }
      if (undefined !==
          classType.registeredClass.constructor_body[argCount - 1]) {
        throw new BindingError(
            `Cannot register multiple constructors with identical number of parameters (${
                argCount - 1}) for class '${
                classType
                    .name}'! Overload resolution is currently only performed using the parameter count, not actual type info!`)
      }
      classType.registeredClass.constructor_body[argCount - 1] = () => {
        throwUnboundTypeError(
            `Cannot construct ${classType.name} due to unbound types`,
            rawArgTypes)
      };
      whenDependentTypesAreResolved([], rawArgTypes, argTypes => {
        argTypes.splice(1, 0, null);
        classType.registeredClass.constructor_body[argCount - 1] =
            craftInvokerFunction(
                humanName, argTypes, null, invoker, rawConstructor);
        return []
      });
      return []
    })
  };
  var getFunctionName = signature => {
    signature = signature.trim();
    const argsIndex = signature.indexOf('(');
    if (argsIndex === -1) return signature;
    return signature.slice(0, argsIndex)
  };
  var __embind_register_class_function = function(
      rawClassType, methodName, argCount, rawArgTypesAddr, invokerSignature,
      rawInvoker, context, isPureVirtual, isAsync, isNonnullReturn) {
    rawClassType >>>= 0;
    methodName >>>= 0;
    rawArgTypesAddr >>>= 0;
    invokerSignature >>>= 0;
    rawInvoker >>>= 0;
    context >>>= 0;
    var rawArgTypes = heap32VectorToArray(argCount, rawArgTypesAddr);
    methodName = AsciiToString(methodName);
    methodName = getFunctionName(methodName);
    rawInvoker = embind__requireFunction(invokerSignature, rawInvoker, isAsync);
    whenDependentTypesAreResolved([], [rawClassType], classType => {
      classType = classType[0];
      var humanName = `${classType.name}.${methodName}`;
      if (methodName.startsWith('@@')) {
        methodName = Symbol[methodName.substring(2)]
      }
      if (isPureVirtual) {
        classType.registeredClass.pureVirtualFunctions.push(methodName)
      }
      function unboundTypesHandler() {
        throwUnboundTypeError(
            `Cannot call ${humanName} due to unbound types`, rawArgTypes)
      }
      var proto = classType.registeredClass.instancePrototype;
      var method = proto[methodName];
      if (undefined === method ||
          undefined === method.overloadTable &&
              method.className !== classType.name &&
              method.argCount === argCount - 2) {
        unboundTypesHandler.argCount = argCount - 2;
        unboundTypesHandler.className = classType.name;
        proto[methodName] = unboundTypesHandler
      } else {
        ensureOverloadTable(proto, methodName, humanName);
        proto[methodName].overloadTable[argCount - 2] = unboundTypesHandler
      }
      whenDependentTypesAreResolved([], rawArgTypes, argTypes => {
        var memberFunction = craftInvokerFunction(
            humanName, argTypes, classType, rawInvoker, context, isAsync);
        if (undefined === proto[methodName].overloadTable) {
          memberFunction.argCount = argCount - 2;
          proto[methodName] = memberFunction
        } else {
          proto[methodName].overloadTable[argCount - 2] = memberFunction
        }
        return []
      });
      return []
    })
  };
  var emval_freelist = [];
  var emval_handles = [0, 1, , 1, null, 1, true, 1, false, 1];
  function __emval_decref(handle) {
    handle >>>= 0;
    if (handle > 9 && 0 === --emval_handles[handle + 1]) {
      emval_handles[handle] = undefined;
      emval_freelist.push(handle)
    }
  }
  var Emval = {
    toValue: handle => {
      if (!handle) {
        throwBindingError(`Cannot use deleted val. handle = ${handle}`)
      }
      return emval_handles[handle]
    },
    toHandle: value => {
      switch (value) {
        case undefined:
          return 2;
        case null:
          return 4;
        case true:
          return 6;
        case false:
          return 8;
        default: {
          const handle = emval_freelist.pop() || emval_handles.length;
          emval_handles[handle] = value;
          emval_handles[handle + 1] = 1;
          return handle
        }
      }
    }
  };
  var EmValType = {
    name: 'emscripten::val',
    fromWireType: handle => {
      var rv = Emval.toValue(handle);
      __emval_decref(handle);
      return rv
    },
    toWireType: (destructors, value) => Emval.toHandle(value),
    readValueFromPointer: readPointer,
    destructorFunction: null
  };
  function __embind_register_emval(rawType) {
    rawType >>>= 0;
    return registerType(rawType, EmValType)
  }
  var enumReadValueFromPointer = (name, width, signed) => {
    switch (width) {
      case 1:
        return signed ? function(pointer) {
          return this.fromWireType(HEAP8[pointer >>> 0])
        } : function(pointer) {
          return this.fromWireType(HEAPU8[pointer >>> 0])
        };
      case 2:
        return signed ? function(pointer) {
          return this.fromWireType(HEAP16[pointer >>> 1 >>> 0])
        } : function(pointer) {
          return this.fromWireType(HEAPU16[pointer >>> 1 >>> 0])
        };
      case 4:
        return signed ? function(pointer) {
          return this.fromWireType(HEAP32[pointer >>> 2 >>> 0])
        } : function(pointer) {
          return this.fromWireType(HEAPU32[pointer >>> 2 >>> 0])
        };
      default:
        throw new TypeError(`invalid integer width (${width}): ${name}`)
    }
  };
  function __embind_register_enum(rawType, name, size, isSigned) {
    rawType >>>= 0;
    name >>>= 0;
    size >>>= 0;
    name = AsciiToString(name);
    function ctor() {}
    ctor.values = {};
    registerType(rawType, {
      name,
      constructor: ctor,
      fromWireType: function(c) {
        return this.constructor.values[c]
      },
      toWireType: (destructors, c) => c.value,
      readValueFromPointer: enumReadValueFromPointer(name, size, isSigned),
      destructorFunction: null
    });
    exposePublicSymbol(name, ctor)
  }
  var requireRegisteredType = (rawType, humanName) => {
    var impl = registeredTypes[rawType];
    if (undefined === impl) {
      throwBindingError(`${humanName} has unknown type ${getTypeName(rawType)}`)
    }
    return impl
  };
  function __embind_register_enum_value(rawEnumType, name, enumValue) {
    rawEnumType >>>= 0;
    name >>>= 0;
    var enumType = requireRegisteredType(rawEnumType, 'enum');
    name = AsciiToString(name);
    var Enum = enumType.constructor;
    var Value = Object.create(enumType.constructor.prototype, {
      value: {value: enumValue},
      constructor: {
        value: createNamedFunction(`${enumType.name}_${name}`, function() {})
      }
    });
    Enum.values[enumValue] = Value;
    Enum[name] = Value
  }
  var floatReadValueFromPointer = (name, width) => {
    switch (width) {
      case 4:
        return function(pointer) {
          return this.fromWireType(HEAPF32[pointer >>> 2 >>> 0])
        };
      case 8:
        return function(pointer) {
          return this.fromWireType(HEAPF64[pointer >>> 3 >>> 0])
        };
      default:
        throw new TypeError(`invalid float width (${width}): ${name}`)
    }
  };
  var __embind_register_float = function(rawType, name, size) {
    rawType >>>= 0;
    name >>>= 0;
    size >>>= 0;
    name = AsciiToString(name);
    registerType(rawType, {
      name,
      fromWireType: value => value,
      toWireType: (destructors, value) => value,
      readValueFromPointer: floatReadValueFromPointer(name, size),
      destructorFunction: null
    })
  };
  function __embind_register_function(
      name, argCount, rawArgTypesAddr, signature, rawInvoker, fn, isAsync,
      isNonnullReturn) {
    name >>>= 0;
    rawArgTypesAddr >>>= 0;
    signature >>>= 0;
    rawInvoker >>>= 0;
    fn >>>= 0;
    var argTypes = heap32VectorToArray(argCount, rawArgTypesAddr);
    name = AsciiToString(name);
    name = getFunctionName(name);
    rawInvoker = embind__requireFunction(signature, rawInvoker, isAsync);
    exposePublicSymbol(name, function() {
      throwUnboundTypeError(
          `Cannot call ${name} due to unbound types`, argTypes)
    }, argCount - 1);
    whenDependentTypesAreResolved([], argTypes, argTypes => {
      var invokerArgsArray = [argTypes[0], null].concat(argTypes.slice(1));
      replacePublicSymbol(
          name,
          craftInvokerFunction(
              name, invokerArgsArray, null, rawInvoker, fn, isAsync),
          argCount - 1);
      return []
    })
  }
  var __embind_register_integer = function(
      primitiveType, name, size, minRange, maxRange) {
    primitiveType >>>= 0;
    name >>>= 0;
    size >>>= 0;
    name = AsciiToString(name);
    const isUnsignedType = minRange === 0;
    let fromWireType = value => value;
    if (isUnsignedType) {
      var bitshift = 32 - 8 * size;
      fromWireType = value => value << bitshift >>> bitshift;
      maxRange = fromWireType(maxRange)
    }
    registerType(primitiveType, {
      name,
      fromWireType,
      toWireType: (destructors, value) => value,
      readValueFromPointer:
          integerReadValueFromPointer(name, size, minRange !== 0),
      destructorFunction: null
    })
  };
  function __embind_register_memory_view(rawType, dataTypeIndex, name) {
    rawType >>>= 0;
    name >>>= 0;
    var typeMapping = [
      Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array,
      Float32Array, Float64Array, BigInt64Array, BigUint64Array
    ];
    var TA = typeMapping[dataTypeIndex];
    function decodeMemoryView(handle) {
      var size = HEAPU32[handle >>> 2 >>> 0];
      var data = HEAPU32[handle + 4 >>> 2 >>> 0];
      return new TA(HEAP8.buffer, data, size)
    }
    name = AsciiToString(name);
    registerType(
        rawType, {
          name,
          fromWireType: decodeMemoryView,
          readValueFromPointer: decodeMemoryView
        },
        {ignoreDuplicateRegistrations: true})
  }
  var EmValOptionalType = Object.assign({optional: true}, EmValType);
  function __embind_register_optional(rawOptionalType, rawType) {
    rawOptionalType >>>= 0;
    rawType >>>= 0;
    registerType(rawOptionalType, EmValOptionalType)
  }
  var stringToUTF8Array = (str, heap, outIdx, maxBytesToWrite) => {
    outIdx >>>= 0;
    if (!(maxBytesToWrite > 0)) return 0;
    var startIdx = outIdx;
    var endIdx = outIdx + maxBytesToWrite - 1;
    for (var i = 0; i < str.length; ++i) {
      var u = str.codePointAt(i);
      if (u <= 127) {
        if (outIdx >= endIdx) break;
        heap[outIdx++ >>> 0] = u
      } else if (u <= 2047) {
        if (outIdx + 1 >= endIdx) break;
        heap[outIdx++ >>> 0] = 192 | u >> 6;
        heap[outIdx++ >>> 0] = 128 | u & 63
      } else if (u <= 65535) {
        if (outIdx + 2 >= endIdx) break;
        heap[outIdx++ >>> 0] = 224 | u >> 12;
        heap[outIdx++ >>> 0] = 128 | u >> 6 & 63;
        heap[outIdx++ >>> 0] = 128 | u & 63
      } else {
        if (outIdx + 3 >= endIdx) break;
        heap[outIdx++ >>> 0] = 240 | u >> 18;
        heap[outIdx++ >>> 0] = 128 | u >> 12 & 63;
        heap[outIdx++ >>> 0] = 128 | u >> 6 & 63;
        heap[outIdx++ >>> 0] = 128 | u & 63;
        i++
      }
    }
    heap[outIdx >>> 0] = 0;
    return outIdx - startIdx
  };
  var stringToUTF8 = (str, outPtr, maxBytesToWrite) =>
      stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
  var lengthBytesUTF8 = str => {
    var len = 0;
    for (var i = 0; i < str.length; ++i) {
      var c = str.charCodeAt(i);
      if (c <= 127) {
        len++
      } else if (c <= 2047) {
        len += 2
      } else if (c >= 55296 && c <= 57343) {
        len += 4;
        ++i
      } else {
        len += 3
      }
    }
    return len
  };
  var UTF8Decoder =
      typeof TextDecoder != 'undefined' ? new TextDecoder : undefined;
  var findStringEnd = (heapOrArray, idx, maxBytesToRead, ignoreNul) => {
    var maxIdx = idx + maxBytesToRead;
    if (ignoreNul) return maxIdx;
    while (heapOrArray[idx] && !(idx >= maxIdx)) ++idx;
    return idx
  };
  var UTF8ArrayToString = (heapOrArray, idx = 0, maxBytesToRead, ignoreNul) => {
    idx >>>= 0;
    var endPtr = findStringEnd(heapOrArray, idx, maxBytesToRead, ignoreNul);
    if (endPtr - idx > 16 && heapOrArray.buffer && UTF8Decoder) {
      return UTF8Decoder.decode(heapOrArray.subarray(idx, endPtr))
    }
    var str = '';
    while (idx < endPtr) {
      var u0 = heapOrArray[idx++];
      if (!(u0 & 128)) {
        str += String.fromCharCode(u0);
        continue
      }
      var u1 = heapOrArray[idx++] & 63;
      if ((u0 & 224) == 192) {
        str += String.fromCharCode((u0 & 31) << 6 | u1);
        continue
      }
      var u2 = heapOrArray[idx++] & 63;
      if ((u0 & 240) == 224) {
        u0 = (u0 & 15) << 12 | u1 << 6 | u2
      } else {
        u0 = (u0 & 7) << 18 | u1 << 12 | u2 << 6 | heapOrArray[idx++] & 63
      }
      if (u0 < 65536) {
        str += String.fromCharCode(u0)
      } else {
        var ch = u0 - 65536;
        str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023)
      }
    }
    return str
  };
  var UTF8ToString = (ptr, maxBytesToRead, ignoreNul) => {
    ptr >>>= 0;
    return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead, ignoreNul) : ''
  };
  function __embind_register_std_string(rawType, name) {
    rawType >>>= 0;
    name >>>= 0;
    name = AsciiToString(name);
    var stdStringIsUTF8 = true;
    registerType(rawType, {
      name,
      fromWireType(value) {
        var length = HEAPU32[value >>> 2 >>> 0];
        var payload = value + 4;
        var str;
        if (stdStringIsUTF8) {
          str = UTF8ToString(payload, length, true)
        } else {
          str = '';
          for (var i = 0; i < length; ++i) {
            str += String.fromCharCode(HEAPU8[payload + i >>> 0])
          }
        }
        _free(value);
        return str
      },
      toWireType(destructors, value) {
        if (value instanceof ArrayBuffer) {
          value = new Uint8Array(value)
        }
        var length;
        var valueIsOfTypeString = typeof value == 'string';
        if (!(valueIsOfTypeString ||
              ArrayBuffer.isView(value) && value.BYTES_PER_ELEMENT == 1)) {
          throwBindingError('Cannot pass non-string to std::string')
        }
        if (stdStringIsUTF8 && valueIsOfTypeString) {
          length = lengthBytesUTF8(value)
        } else {
          length = value.length
        }
        var base = _malloc(4 + length + 1);
        var ptr = base + 4;
        HEAPU32[base >>> 2 >>> 0] = length;
        if (valueIsOfTypeString) {
          if (stdStringIsUTF8) {
            stringToUTF8(value, ptr, length + 1)
          } else {
            for (var i = 0; i < length; ++i) {
              var charCode = value.charCodeAt(i);
              if (charCode > 255) {
                _free(base);
                throwBindingError(
                    'String has UTF-16 code units that do not fit in 8 bits')
              }
              HEAPU8[ptr + i >>> 0] = charCode
            }
          }
        } else {
          HEAPU8.set(value, ptr >>> 0)
        }
        if (destructors !== null) {
          destructors.push(_free, base)
        }
        return base
      },
      readValueFromPointer: readPointer,
      destructorFunction(ptr) {
        _free(ptr)
      }
    })
  }
  var UTF16Decoder = typeof TextDecoder != 'undefined' ?
      new TextDecoder('utf-16le') :
      undefined;
  var UTF16ToString = (ptr, maxBytesToRead, ignoreNul) => {
    var idx = ptr >>> 1;
    var endIdx = findStringEnd(HEAPU16, idx, maxBytesToRead / 2, ignoreNul);
    if (endIdx - idx > 16 && UTF16Decoder)
      return UTF16Decoder.decode(HEAPU16.subarray(idx >>> 0, endIdx >>> 0));
    var str = '';
    for (var i = idx; i < endIdx; ++i) {
      var codeUnit = HEAPU16[i >>> 0];
      str += String.fromCharCode(codeUnit)
    }
    return str
  };
  var stringToUTF16 = (str, outPtr, maxBytesToWrite) => {
    maxBytesToWrite ??= 2147483647;
    if (maxBytesToWrite < 2) return 0;
    maxBytesToWrite -= 2;
    var startPtr = outPtr;
    var numCharsToWrite =
        maxBytesToWrite < str.length * 2 ? maxBytesToWrite / 2 : str.length;
    for (var i = 0; i < numCharsToWrite; ++i) {
      var codeUnit = str.charCodeAt(i);
      HEAP16[outPtr >>> 1 >>> 0] = codeUnit;
      outPtr += 2
    }
    HEAP16[outPtr >>> 1 >>> 0] = 0;
    return outPtr - startPtr
  };
  var lengthBytesUTF16 = str => str.length * 2;
  var UTF32ToString = (ptr, maxBytesToRead, ignoreNul) => {
    var str = '';
    var startIdx = ptr >>> 2;
    for (var i = 0; !(i >= maxBytesToRead / 4); i++) {
      var utf32 = HEAPU32[startIdx + i >>> 0];
      if (!utf32 && !ignoreNul) break;
      str += String.fromCodePoint(utf32)
    }
    return str
  };
  var stringToUTF32 = (str, outPtr, maxBytesToWrite) => {
    outPtr >>>= 0;
    maxBytesToWrite ??= 2147483647;
    if (maxBytesToWrite < 4) return 0;
    var startPtr = outPtr;
    var endPtr = startPtr + maxBytesToWrite - 4;
    for (var i = 0; i < str.length; ++i) {
      var codePoint = str.codePointAt(i);
      if (codePoint > 65535) {
        i++
      }
      HEAP32[outPtr >>> 2 >>> 0] = codePoint;
      outPtr += 4;
      if (outPtr + 4 > endPtr) break
    }
    HEAP32[outPtr >>> 2 >>> 0] = 0;
    return outPtr - startPtr
  };
  var lengthBytesUTF32 = str => {
    var len = 0;
    for (var i = 0; i < str.length; ++i) {
      var codePoint = str.codePointAt(i);
      if (codePoint > 65535) {
        i++
      }
      len += 4
    }
    return len
  };
  function __embind_register_std_wstring(rawType, charSize, name) {
    rawType >>>= 0;
    charSize >>>= 0;
    name >>>= 0;
    name = AsciiToString(name);
    var decodeString, encodeString, lengthBytesUTF;
    if (charSize === 2) {
      decodeString = UTF16ToString;
      encodeString = stringToUTF16;
      lengthBytesUTF = lengthBytesUTF16
    } else {
      decodeString = UTF32ToString;
      encodeString = stringToUTF32;
      lengthBytesUTF = lengthBytesUTF32
    }
    registerType(rawType, {
      name,
      fromWireType: value => {
        var length = HEAPU32[value >>> 2 >>> 0];
        var str = decodeString(value + 4, length * charSize, true);
        _free(value);
        return str
      },
      toWireType: (destructors, value) => {
        if (!(typeof value == 'string')) {
          throwBindingError(`Cannot pass non-string to C++ string type ${name}`)
        }
        var length = lengthBytesUTF(value);
        var ptr = _malloc(4 + length + charSize);
        HEAPU32[ptr >>> 2 >>> 0] = length / charSize;
        encodeString(value, ptr + 4, length + charSize);
        if (destructors !== null) {
          destructors.push(_free, ptr)
        }
        return ptr
      },
      readValueFromPointer: readPointer,
      destructorFunction(ptr) {
        _free(ptr)
      }
    })
  }
  function __embind_register_value_object(
      rawType, name, constructorSignature, rawConstructor, destructorSignature,
      rawDestructor) {
    rawType >>>= 0;
    name >>>= 0;
    constructorSignature >>>= 0;
    rawConstructor >>>= 0;
    destructorSignature >>>= 0;
    rawDestructor >>>= 0;
    structRegistrations[rawType] = {
      name: AsciiToString(name),
      rawConstructor:
          embind__requireFunction(constructorSignature, rawConstructor),
      rawDestructor:
          embind__requireFunction(destructorSignature, rawDestructor),
      fields: []
    }
  }
  function __embind_register_value_object_field(
      structType, fieldName, getterReturnType, getterSignature, getter,
      getterContext, setterArgumentType, setterSignature, setter,
      setterContext) {
    structType >>>= 0;
    fieldName >>>= 0;
    getterReturnType >>>= 0;
    getterSignature >>>= 0;
    getter >>>= 0;
    getterContext >>>= 0;
    setterArgumentType >>>= 0;
    setterSignature >>>= 0;
    setter >>>= 0;
    setterContext >>>= 0;
    structRegistrations[structType].fields.push({
      fieldName: AsciiToString(fieldName),
      getterReturnType,
      getter: embind__requireFunction(getterSignature, getter),
      getterContext,
      setterArgumentType,
      setter: embind__requireFunction(setterSignature, setter),
      setterContext
    })
  }
  var __embind_register_void = function(rawType, name) {
    rawType >>>= 0;
    name >>>= 0;
    name = AsciiToString(name);
    registerType(rawType, {
      isVoid: true,
      name,
      fromWireType: () => undefined,
      toWireType: (destructors, o) => undefined
    })
  };
  var emval_methodCallers = [];
  var emval_addMethodCaller = caller => {
    var id = emval_methodCallers.length;
    emval_methodCallers.push(caller);
    return id
  };
  var emval_lookupTypes = (argCount, argTypes) => {
    var a = new Array(argCount);
    for (var i = 0; i < argCount; ++i) {
      a[i] = requireRegisteredType(
          HEAPU32[argTypes + i * 4 >>> 2 >>> 0], `parameter ${i}`)
    }
    return a
  };
  var emval_returnValue = (toReturnWire, destructorsRef, handle) => {
    var destructors = [];
    var result = toReturnWire(destructors, handle);
    if (destructors.length) {
      HEAPU32[destructorsRef >>> 2 >>> 0] = Emval.toHandle(destructors)
    }
    return result
  };
  var emval_symbols = {};
  var getStringOrSymbol = address => {
    var symbol = emval_symbols[address];
    if (symbol === undefined) {
      return AsciiToString(address)
    }
    return symbol
  };
  var __emval_create_invoker = function(argCount, argTypesPtr, kind) {
    argTypesPtr >>>= 0;
    var GenericWireTypeSize = 8;
    var [retType, ...argTypes] = emval_lookupTypes(argCount, argTypesPtr);
    var toReturnWire = retType.toWireType.bind(retType);
    var argFromPtr = argTypes.map(type => type.readValueFromPointer.bind(type));
    argCount--;
    var captures = {toValue: Emval.toValue};
    var args = argFromPtr.map((argFromPtr, i) => {
      var captureName = `argFromPtr${i}`;
      captures[captureName] = argFromPtr;
      return `${captureName}(args${i ? '+' + i * GenericWireTypeSize : ''})`
    });
    var functionBody;
    switch (kind) {
      case 0:
        functionBody = 'toValue(handle)';
        break;
      case 2:
        functionBody = 'new (toValue(handle))';
        break;
      case 3:
        functionBody = '';
        break;
      case 1:
        captures['getStringOrSymbol'] = getStringOrSymbol;
        functionBody = 'toValue(handle)[getStringOrSymbol(methodName)]';
        break
    }
    functionBody += `(${args})`;
    if (!retType.isVoid) {
      captures['toReturnWire'] = toReturnWire;
      captures['emval_returnValue'] = emval_returnValue;
      functionBody = `return emval_returnValue(toReturnWire, destructorsRef, ${
          functionBody})`
    }
    functionBody =
        `return function (handle, methodName, destructorsRef, args) {\n  ${
            functionBody}\n  }`;
    var invokerFunction = new Function(
        Object.keys(captures), functionBody)(...Object.values(captures));
    var functionName =
        `methodCaller<(${argTypes.map(t => t.name)}) => ${retType.name}>`;
    return emval_addMethodCaller(
        createNamedFunction(functionName, invokerFunction))
  };
  function __emval_equals(first, second) {
    first >>>= 0;
    second >>>= 0;
    first = Emval.toValue(first);
    second = Emval.toValue(second);
    return first == second
  }
  function __emval_get_property(handle, key) {
    handle >>>= 0;
    key >>>= 0;
    handle = Emval.toValue(handle);
    key = Emval.toValue(key);
    return Emval.toHandle(handle[key])
  }
  function __emval_incref(handle) {
    handle >>>= 0;
    if (handle > 9) {
      emval_handles[handle + 1] += 1
    }
  }
  function __emval_invoke(caller, handle, methodName, destructorsRef, args) {
    caller >>>= 0;
    handle >>>= 0;
    methodName >>>= 0;
    destructorsRef >>>= 0;
    args >>>= 0;
    return emval_methodCallers[caller](handle, methodName, destructorsRef, args)
  }
  function __emval_new_cstring(v) {
    v >>>= 0;
    return Emval.toHandle(getStringOrSymbol(v))
  }
  function __emval_new_object() {
    return Emval.toHandle({})
  }
  function __emval_run_destructors(handle) {
    handle >>>= 0;
    var destructors = Emval.toValue(handle);
    runDestructors(destructors);
    __emval_decref(handle)
  }
  function __emval_set_property(handle, key, value) {
    handle >>>= 0;
    key >>>= 0;
    value >>>= 0;
    handle = Emval.toValue(handle);
    key = Emval.toValue(key);
    value = Emval.toValue(value);
    handle[key] = value
  }
  var getHeapMax = () => 4294901760;
  var alignMemory = (size, alignment) =>
      Math.ceil(size / alignment) * alignment;
  var growMemory = size => {
    var oldHeapSize = wasmMemory.buffer.byteLength;
    var pages = (size - oldHeapSize + 65535) / 65536 | 0;
    try {
      wasmMemory.grow(pages);
      updateMemoryViews();
      return 1
    } catch (e) {
    }
  };
  function _emscripten_resize_heap(requestedSize) {
    requestedSize >>>= 0;
    var oldSize = HEAPU8.length;
    var maxHeapSize = getHeapMax();
    if (requestedSize > maxHeapSize) {
      return false
    }
    for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
      var overGrownHeapSize = oldSize * (1 + .2 / cutDown);
      overGrownHeapSize =
          Math.min(overGrownHeapSize, requestedSize + 100663296);
      var newSize = Math.min(
          maxHeapSize,
          alignMemory(Math.max(requestedSize, overGrownHeapSize), 65536));
      var replacement = growMemory(newSize);
      if (replacement) {
        return true
      }
    }
    return false
  }
  var uleb128EncodeWithLen = arr => {
    const n = arr.length;
    return [n % 128 | 128, n >> 7, ...arr]
  };
  var wasmTypeCodes = {i: 127, p: 127, j: 126, f: 125, d: 124, e: 111};
  var generateTypePack = types =>
      uleb128EncodeWithLen(Array.from(types, type => {
        var code = wasmTypeCodes[type];
        return code
      }));
  var convertJsFunctionToWasm = (func, sig) => {
    var bytes = Uint8Array.of(
        0, 97, 115, 109, 1, 0, 0, 0, 1, ...uleb128EncodeWithLen([
          1, 96, ...generateTypePack(sig.slice(1)),
          ...generateTypePack(sig[0] === 'v' ? '' : sig[0])
        ]),
        2, 7, 1, 1, 101, 1, 102, 0, 0, 7, 5, 1, 1, 102, 0, 0);
    var module = new WebAssembly.Module(bytes);
    var instance = new WebAssembly.Instance(module, {e: {f: func}});
    var wrappedFunc = instance.exports['f'];
    return wrappedFunc
  };
  var updateTableMap = (offset, count) => {
    if (functionsInTableMap) {
      for (var i = offset; i < offset + count; i++) {
        var item = getWasmTableEntry(i);
        if (item) {
          functionsInTableMap.set(item, i)
        }
      }
    }
  };
  var functionsInTableMap;
  var getFunctionAddress = func => {
    if (!functionsInTableMap) {
      functionsInTableMap = new WeakMap;
      updateTableMap(0, wasmTable.length)
    }
    return functionsInTableMap.get(func) || 0
  };
  var freeTableIndexes = [];
  var getEmptyTableSlot = () => {
    if (freeTableIndexes.length) {
      return freeTableIndexes.pop()
    }
    return wasmTable['grow'](1)
  };
  var setWasmTableEntry = (idx, func) => wasmTable.set(idx, func);
  var addFunction = (func, sig) => {
    var rtn = getFunctionAddress(func);
    if (rtn) {
      return rtn
    }
    var ret = getEmptyTableSlot();
    try {
      setWasmTableEntry(ret, func)
    } catch (err) {
      if (!(err instanceof TypeError)) {
        throw err
      }
      var wrapped = convertJsFunctionToWasm(func, sig);
      setWasmTableEntry(ret, wrapped)
    }
    functionsInTableMap.set(func, ret);
    return ret
  };
  var removeFunction = index => {
    functionsInTableMap.delete(getWasmTableEntry(index));
    setWasmTableEntry(index, null);
    freeTableIndexes.push(index)
  };
  init_ClassHandle();
  init_RegisteredPointer();
  {
    if (Module['noExitRuntime']) noExitRuntime = Module['noExitRuntime'];
    if (Module['print']) out = Module['print'];
    if (Module['printErr']) err = Module['printErr'];
    if (Module['wasmBinary']) wasmBinary = Module['wasmBinary'];
    if (Module['arguments']) arguments_ = Module['arguments'];
    if (Module['thisProgram']) thisProgram = Module['thisProgram']
  }
  Module['addFunction'] = addFunction;
  Module['removeFunction'] = removeFunction;
  var ___getTypeName, _malloc, _free;
  function assignWasmExports(wasmExports) {
    ___getTypeName = wasmExports['I'];
    _malloc = wasmExports['K'];
    _free = wasmExports['L']
  }
  var wasmImports = {
    k: ___cxa_throw,
    A: __abort_js,
    o: __embind_finalize_value_object,
    x: __embind_register_bigint,
    E: __embind_register_bool,
    j: __embind_register_class,
    i: __embind_register_class_constructor,
    a: __embind_register_class_function,
    C: __embind_register_emval,
    t: __embind_register_enum,
    d: __embind_register_enum_value,
    w: __embind_register_float,
    c: __embind_register_function,
    l: __embind_register_integer,
    e: __embind_register_memory_view,
    m: __embind_register_optional,
    D: __embind_register_std_string,
    v: __embind_register_std_wstring,
    p: __embind_register_value_object,
    n: __embind_register_value_object_field,
    F: __embind_register_void,
    h: __emval_create_invoker,
    b: __emval_decref,
    q: __emval_equals,
    z: __emval_get_property,
    r: __emval_incref,
    g: __emval_invoke,
    s: __emval_new_cstring,
    y: __emval_new_object,
    f: __emval_run_destructors,
    u: __emval_set_property,
    B: _emscripten_resize_heap
  };
  var wasmExports = await createWasm();
  function applySignatureConversions(wasmExports) {
    wasmExports = Object.assign({}, wasmExports);
    var makeWrapper_pp = f => a0 => f(a0) >>> 0;
    var makeWrapper_p = f => () => f() >>> 0;
    wasmExports['I'] = makeWrapper_pp(wasmExports['I']);
    wasmExports['K'] = makeWrapper_pp(wasmExports['K']);
    wasmExports['_emscripten_stack_alloc'] =
        makeWrapper_pp(wasmExports['_emscripten_stack_alloc']);
    wasmExports['emscripten_stack_get_current'] =
        makeWrapper_p(wasmExports['emscripten_stack_get_current']);
    return wasmExports
  }
  function run() {
    if (runDependencies > 0) {
      dependenciesFulfilled = run;
      return
    }
    preRun();
    if (runDependencies > 0) {
      dependenciesFulfilled = run;
      return
    }
    function doRun() {
      Module['calledRun'] = true;
      if (ABORT) return;
      initRuntime();
      readyPromiseResolve?.(Module);
      Module['onRuntimeInitialized']?.();
      postRun()
    }
    if (Module['setStatus']) {
      Module['setStatus']('Running...');
      setTimeout(() => {
        setTimeout(() => Module['setStatus'](''), 1);
        doRun()
      }, 1)
    } else {
      doRun()
    }
  }
  function preInit() {
    if (Module['preInit']) {
      if (typeof Module['preInit'] == 'function')
        Module['preInit'] = [Module['preInit']];
      while (Module['preInit'].length > 0) {
        Module['preInit'].shift()()
      }
    }
  }
  preInit();
  run();
  if (runtimeInitialized) {
    moduleRtn = Module
  } else {
    moduleRtn = new Promise((resolve, reject) => {
      readyPromiseResolve = resolve;
      readyPromiseReject = reject
    })
  };
  return moduleRtn
}
export default Module;
