import { Document } from '@gltf-transform/core';
/**
 * Object to convert GLTF documents to a 3MF binary.
 *
 * @property unit
 * @property title
 * @property author
 * @property description
 * @property application
 * @property creationDate
 * @property license
 * @property modificationDate
 */
export declare class Export3MF {
    extensions: Array<string>;
    unit: 'micron' | 'millimeter' | 'centimeter' | 'inch' | 'foot' | 'meter';
    title?: string;
    author?: string;
    description?: string;
    application?: string;
    creationDate?: string;
    license?: string;
    modificationDate?: string;
    /**
     * Convert a GLTF-Transform document to a 3MF model.
     *
     * @param doc The GLTF document to convert.
     * @returns A blob containing the converted model.
     */
    asBlob(doc: Document): Promise<Blob>;
}
