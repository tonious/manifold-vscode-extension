export declare function setWasmUrl(url: string): void;
export declare function instantiateManifold(): Promise<import("../manifold.js").ManifoldToplevel>;
export declare function getManifoldModule(): Promise<any>;
