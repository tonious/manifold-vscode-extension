/**
 * The scene builder provides modelling outside of the native
 * capabilities of Maniold WASM.  This includes scene graphs, materials,
 * and animation functions.  In general, the scene builder
 * follows GLTF semantics.
 *
 * This module includes modelling functions for use inside a ManifoldCAD script
 * (e.g.: `show`, `only`, `setMaterial`, etc.).  It also includes a set of
 * management functions (e.g.: `manifoldToGLTFDoc`, `cleanup`, etc.) that are
 * used to export complete scenes and generally manage the state of the scene
 * builder.
 *
 * @module scene-builder
 */
import { Document } from '@gltf-transform/core';
import { Manifold } from '../manifold-encapsulated-types';
import { Vec3 } from '../manifold-global-types';
import type { GLTFMaterial } from '../types/manifoldCAD';
export { setMorphEnd, setMorphStart } from './animation.ts';
export { only, show } from './debug.ts';
export { setMaterial } from './material.ts';
export interface GlobalDefaults {
    roughness: number;
    metallic: number;
    baseColorFactor: [number, number, number];
    alpha: number;
    unlit: boolean;
    animationLength: number;
    animationMode: 'loop' | 'ping-pong';
}
export declare const globalDefaults: {
    roughness: number;
    metallic: number;
    baseColorFactor: [number, number, number];
    alpha: number;
    unlit: boolean;
    animationLength: number;
    animationMode: string;
};
/**
 * Reset and garbage collect the scene builder and any
 * encapsulated modules.
 *
 * @group Management Functions
 */
export declare function cleanup(): void;
export declare class GLTFNode {
    private _parent?;
    manifold?: Manifold;
    translation?: Vec3 | ((t: number) => Vec3);
    rotation?: Vec3 | ((t: number) => Vec3);
    scale?: Vec3 | ((t: number) => Vec3);
    material?: GLTFMaterial;
    name?: string;
    constructor(parent?: GLTFNode);
    clone(parent?: GLTFNode): this;
    get parent(): GLTFNode | undefined;
}
/**
 * Convert a Manifold object into a GLTF-Transform Document.
 *
 * @group Management Functions
 * @param manifold The Manifold object
 * @param defaults Parameters potentially set by a ManifoldCAD script
 * @returns An in-memory GLTF-Transform Document
 */
export declare function manifoldToGLTFDoc(manifold: Manifold, defaults: GlobalDefaults): Document;
/**
 * Convert a list of GLTF Nodes into a GLTF-Transform Document.
 *
 * @group Management Functions
 * @param nodes A list of GLTF Nodes
 * @param defaults Parameters potentially set by a ManifoldCAD script
 * @returns An in-memory GLTF-Transform Document
 */
export declare function GLTFNodesToGLTFDoc(nodes: Array<GLTFNode>, defaults: GlobalDefaults): Document;
/**
 * Does the scene builder have any GLTF nodes?
 *
 * @group Management Functions
 * @returns A boolean value
 */
export declare function hasGLTFNodes(): boolean;
/**
 * Get GLTF Nodes from the scene builder.
 *
 * @group Management Functions
 * @returns An array of GLTF Nodes.
 */
export declare function getGLTFNodes(): Array<GLTFNode>;
