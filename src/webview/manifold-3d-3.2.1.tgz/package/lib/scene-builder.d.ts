import { Document } from '@gltf-transform/core';
import { GLTFMaterial } from '../examples/public/editor';
import { Manifold } from '../manifold-encapsulated-types';
import { Vec3 } from '../manifold-global-types';
export { setMorphEnd, setMorphStart } from './animation.ts';
export { only, show } from './debug.ts';
export { setMaterial } from './material.ts';
export interface GlobalDefaults {
    roughness: number;
    metallic: number;
    baseColorFactor: [number, number, number];
    alpha: number;
    unlit: boolean;
    animationLength: number;
    animationMode: 'loop' | 'ping-pong';
}
export declare const globalDefaults: {
    roughness: number;
    metallic: number;
    baseColorFactor: [number, number, number];
    alpha: number;
    unlit: boolean;
    animationLength: number;
    animationMode: string;
};
export declare function cleanup(): void;
export declare class GLTFNode {
    private _parent?;
    manifold?: Manifold;
    translation?: Vec3 | ((t: number) => Vec3);
    rotation?: Vec3 | ((t: number) => Vec3);
    scale?: Vec3 | ((t: number) => Vec3);
    material?: GLTFMaterial;
    name?: string;
    constructor(parent?: GLTFNode);
    clone(parent?: GLTFNode): this;
    get parent(): GLTFNode | undefined;
}
export declare function manifoldToGLTFDoc(manifold: Manifold, defaults: GlobalDefaults): Document;
export declare function GLTFNodesToGLTFDoc(nodes: Array<GLTFNode>, defaults: GlobalDefaults): Document;
export declare function hasGLTFNodes(): boolean;
export declare function getGLTFNodes(): GLTFNode[];
