import { Document, Material } from '@gltf-transform/core';
import { GLTFMaterial } from '../examples/public/editor';
import { Manifold } from '../manifold-encapsulated-types';
import { GLTFNode } from './scene-builder.ts';
export declare function cleanup(): void;
/**
 * Returns a shallow copy of the input manifold with the given material
 * properties applied. They will be carried along through operations.
 *
 * @group Modelling Functions
 * @param manifold The input object.
 * @param material A set of material properties to apply to this manifold.
 */
export declare const setMaterial: (manifold: Manifold, material: GLTFMaterial) => Manifold;
export declare const getMaterialByID: (id: number) => GLTFMaterial | undefined;
export declare function getBackupMaterial(node?: GLTFNode): GLTFMaterial;
export declare function getCachedMaterial(doc: Document, matDef: GLTFMaterial): Material;
