import type { BuildFailure, Location, Message } from 'esbuild';
export declare class BundlerError extends Error {
    location?: Location;
    error: Message;
    constructor(failure: BuildFailure, options?: ErrorOptions);
    get name(): string;
    get message(): string;
    get stack(): string | undefined;
}
export declare class RuntimeError extends Error {
    manifoldStack?: string;
    cause: Error;
    constructor(cause: Error, options?: ErrorOptions);
    get name(): string;
    get message(): string;
    get stack(): string | undefined;
    toString(): string;
}
