/**
 * Are we in a web worker?
 *
 * @returns A boolean.
 */
export declare const isWebWorker: () => boolean;
/**
 * Are we in Node?
 *
 * @returns A boolean.
 */
export declare const isNode: () => boolean;
export declare const getSourceMappedStackTrace: (code: string, error: Error, lineOffset?: number) => string | undefined;
