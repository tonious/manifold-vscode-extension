/**
 * The worker is where the scene builder and evaluator come together.
 * It handles instantiation of an evaluator, execution of a model and
 * exporting the final scene as a GLTF-Transform Document or URL encoded
 * Blob.
 *
 * This is a polymorphic module that can be used directly as a JavaScript or
 * TypeScript module.  It can be imported as a web worker, and defines
 * a set of interfaces for communication in that case.
 *
 * @module worker
 */
import { Document } from '@gltf-transform/core';
import { Evaluator } from './evaluate';
type MessageType = 'initialize' | 'evaluate' | 'export' | 'ready' | 'done' | 'error' | 'log' | 'blob';
export interface Message {
    type: MessageType;
}
export declare namespace MessageToWorker {
    /**
     * Initialize the web worker.
     * If this message is not sent, the worker will
     * be instantiated when first evaluating a model.
     *
     * The worker will respond with `MessageFromWorker.Ready`
     * or `MessageFromWorker.Error`.
     */
    interface Initialize extends Message {
        type: 'initialize';
        manifoldWasmUrl?: string;
    }
    /**
     * Evaluate a ManifoldCAD script.
     *
     * The worker will respond with `MessageFromWorker.Done`
     * or `MessageFromWorker.Error`.
     */
    interface Evaluate extends Message {
        type: 'evaluate';
        code: string;
    }
    /**
     * Export an evaluated model as a URL encoded Blob.
     *
     * The worker will respond with `MessageFromWorker.Blob`
     * or `MessageFromWorker.Error`.
     */
    interface Export extends Message {
        type: 'export';
        extension: string;
    }
}
export declare namespace MessageFromWorker {
    /**
     * The worker is instantiated and ready.
     */
    interface Ready extends Message {
        type: 'ready';
    }
    /**
     * The worker has successfully evaluated a model.
     */
    interface Done extends Message {
        type: 'done';
    }
    /**
     * The worker has encountered an error.
     *
     * After an error, the state of the worker is undefined.
     * Discard it and re-instantiate.
     */
    interface Error extends Message {
        type: 'error';
        message: string;
    }
    /**
     * The worker has emitted a log message.
     *
     * This is not an error condition.  Log messages may
     * be sent at any time.
     */
    interface Log extends Message {
        type: 'log';
        message: string;
    }
    /**
     * The worker has successfully exported a model
     * as a URL encoded Blob.
     */
    interface Blob extends Message {
        type: 'blob';
        blobURL: string;
        extension: string;
    }
}
/**
 * Set up the evaluator, as well as any objects the worker may require.
 *
 * This is where the scene builder meets the evaluator.
 * @returns The evaluator.
 */
export declare function initialize(): Evaluator;
/**
 * Clean up any state stored in the evaluator or scene builder.
 *
 * This includes any outstanding Manifold, Mesh or CrossSection objects,
 * even if referenced elsewhere.
 */
export declare function cleanup(): void;
/**
 * Transform a model from code to a GLTF document.
 *
 * @param code A string containing the code to evaluate.
 * @returns A gltf-transform Document.
 */
export declare function evaluate(code: string): Promise<Document>;
/**
 * Convert an in-memory GLTF document to a URL encoded blob.
 *
 * @param doc The GLTF document.
 * @param extension The target file extension.
 * @returns A URL encoded blob.
 */
export declare const exportBlobURL: (doc: Document, extension: string) => Promise<string>;
export {};
