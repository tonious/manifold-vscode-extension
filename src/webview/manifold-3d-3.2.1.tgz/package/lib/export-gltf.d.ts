import { Document } from '@gltf-transform/core';
/**
 * Object to convert GLTF documents.
 *
 */
export declare class ExportGLTF {
    extensions: Array<string>;
    /**
     * Convert a GLTF-Transform document to a blob.
     *
     * @param doc The GLTF document to convert.
     * @returns A blob containing the converted model.
     */
    asBlob(doc: Document): Promise<Blob>;
}
