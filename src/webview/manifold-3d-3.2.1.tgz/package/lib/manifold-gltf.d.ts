import { Accessor, Extension, ExtensionProperty, IProperty, PropertyType, ReaderContext, WriterContext } from '@gltf-transform/core';
declare const NAME = "EXT_mesh_manifold";
interface IManifoldPrimitive extends IProperty {
    mergeIndices: Accessor;
    mergeValues: Accessor;
    indices: Accessor;
    runIndex: number[] | Uint32Array;
}
export declare class ManifoldPrimitive extends ExtensionProperty<IManifoldPrimitive> {
    static EXTENSION_NAME: string;
    extensionName: typeof NAME;
    propertyType: 'ManifoldPrimitive';
    parentTypes: [PropertyType.MESH];
    init(): void;
    getDefaults(): import("@gltf-transform/core").Nullable<IManifoldPrimitive> & {
        manifoldPrimitive: null;
        mergeIndices: null;
        mergeValues: null;
    };
    getMergeIndices(): (import("property-graph").GraphNode<object> & Accessor) | null;
    getMergeValues(): (import("property-graph").GraphNode<object> & Accessor) | null;
    setMerge(indicesAccessor: Accessor, valuesAccessor: Accessor): this;
    getRunIndex(): number[] | Uint32Array<ArrayBufferLike>;
    setRunIndex(runIndex: number[] | Uint32Array): this;
    setIndices(indices: Accessor): this;
    getIndices(): import("property-graph").GraphNode<object> & Accessor;
}
export declare class EXTManifold extends Extension {
    extensionName: string;
    prewriteTypes: PropertyType[];
    static EXTENSION_NAME: string;
    createManifoldPrimitive(): ManifoldPrimitive;
    read(context: ReaderContext): this;
    prewrite(context: WriterContext): this;
    write(context: WriterContext): this;
}
export {};
