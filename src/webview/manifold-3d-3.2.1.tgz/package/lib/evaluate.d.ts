/**
 * The evaluator executes ManifoldCAD scripts.  It allows
 *
 *
 * It also manages the Manifold WASM object.  This includes
 * instantiation as well as simple garbage collection on Manifold
 * and CrossSection objects.
 *
 * @module evaluate
 */
import { CrossSection, Manifold } from '../manifold-encapsulated-types';
import type { ManifoldToplevel } from '../manifold.d.ts';
/**
 * An object that will evaluate ManifoldCAD scripts on demand.
 *
 * It inserts the Manifold instance (`module`) into the evaluation
 * context, as well as a selection of available methods.  Additional
 * properties can be inserted through `addContext`,
 * `addContextMethodWithCleanup` or can be directly added to the
 * `context` property.
 *
 * This class provides some simple garbage collection.  It does this by
 * intercepting calls to a white-list of functions, tracking new
 * instances of `Manifold` and `CrossSection`.  This way, users don't
 * have to care about calling `delete` manually.  Note that this only
 * fixes memory leak across different runs: the memory will only be freed
 * when `cleanup()` is called.
 *
 * @property context Additional objects inserted into the evaluation
 * context.
 * @property beforeScript Boilerplate script run before the supplied
 * code.
 * @property afterScript Boilerplate code run after the supplied code.
 */
export declare class Evaluator {
    context: any;
    beforeScript: string;
    afterScript: string;
    protected module: ManifoldToplevel | undefined;
    protected memoryRegistry: Array<Manifold | CrossSection>;
    protected moduleIntercepted: boolean;
    /**
     * Construct a new evaluator.
     *
     * @param module An optional Manifold module instance.
     */
    constructor(module?: ManifoldToplevel);
    /**
     * Pass an existing, instantiated manifold module to this evaluator.
     *
     * @param module The manifold module to use.
     */
    setModule(module: ManifoldToplevel): void;
    /**
     * Clear the evaluation context.
     */
    clearContext(): void;
    /**
     * Add objects to the evaluation context.
     *
     * @param moreContext An object containing properties or methods.
     */
    addContext(moreContext: Record<string, any>): void;
    /**
     * Add a method to the evaluation context, with cleanup.
     *
     * Calls to the method will be intercepted, and their results
     * added to the cleanup list.  If your function does not
     * generate new Manifold or CrossSection objects, you can
     * add it to the context directly.
     * @param name The name for the method in the context.
     * @param originalFn The function to intercept and include.
     */
    addContextMethodWithCleanup(name: string, originalFn: any): void;
    /**
     * Delete any objects tagged for garbage collection.
     */
    cleanup(): void;
    /**
     * Set up garbage collection for a white listed set of methods belonging
     * to the Manifold WASM module.
     */
    protected setupGarbageCollection(): undefined;
    /**
     * Intercept calls and add their results to our garbage collection
     * list.
     *
     * @param className The class to intercept.
     * @param methodNames An array of methods to intercept.
     * @param areStatic Are these static methods?  If so, intercept them at
     * the prototype level.
     */
    protected addMembers(className: string, methodNames: Array<string>, areStatic: boolean): void;
    /**
     * Evaluate a string as javascript code creating a Manifold model.
     *
     * This function assembles the final execution context.  It then runs
     * `beforeScript`, `code` and `afterScript` in order.  Finally, it
     * returns the end result.
     *
     * @param code The input string.
     * @returns any By default, this script will return either `undefined`
     * or a `Manifold` object.  Changing `afterScript` will affect this
     * behaviour.
     */
    evaluate(code: string): Promise<any>;
    /**
     * Get the instantiated manifold WASM instance owned by this module.
     *
     * Note that function calls that have been intercepted for garbage
     * collection will continue to be intercepted, even outside of the evaluator.
     */
    getModule(): ManifoldToplevel;
}
