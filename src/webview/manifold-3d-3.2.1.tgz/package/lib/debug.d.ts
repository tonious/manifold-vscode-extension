import { Document } from '@gltf-transform/core';
import { Manifold, Mesh } from '../manifold-encapsulated-types';
import type { GLTFMaterial } from '../types/manifoldCAD';
import { Properties } from './gltf-io.ts';
export declare const SHOW: GLTFMaterial;
export declare const GHOST: GLTFMaterial;
export declare function cleanup(): void;
/**
 * Override materials when debugging.
 *
 * When a mesh is flagged with `only`, we set the `ghost` global.
 * Everything gets rendered in the GHOST material, while the flagged
 * mesh is added as a debug node.
 *
 * @param id The `originalID` of the mesh.
 */
export declare const getMaterialByID: (id: number) => GLTFMaterial | undefined;
/**
 * Wrap any shape object with this method to display it and any copies in
 * transparent red. This is particularly useful for debugging `subtract()` as it
 * will allow you find the object even if it doesn't currently intersect the
 * result.
 *
 * @group Modelling Functions
 * @param shape The object to show - returned for chaining.
 */
export declare const show: (manifold: Manifold) => Manifold;
/**
 * Wrap any shape object with this method to display it and any copies as the
 * result, while ghosting out the final result in transparent gray. Helpful for
 * debugging as it allows you to see objects that may be hidden in the interior
 * of the result. Multiple objects marked `only()` will all be shown.
 *
 * @group Modelling Functions
 * @param shape The object to show - returned for chaining.
 */
export declare const only: (manifold: Manifold) => Manifold;
export declare const getDebugGLTFMesh: (doc: Document, manifoldMesh: Mesh, id2properties: Map<number, Properties>, backupMaterial?: GLTFMaterial) => import("@gltf-transform/core").Node[];
