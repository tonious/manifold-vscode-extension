import { Vec3 } from '../manifold-global-types';
type Vec4 = [number, number, number, number];
export declare function euler2quat(rotation: Vec3): Vec4;
export {};
