import { Quat } from '../examples/public/editor';
import { Vec3 } from '../manifold-global-types';
export declare function euler2quat(rotation: Vec3): Quat;
