import { Document, Mesh as GLTFMesh, Node } from '@gltf-transform/core';
import { Manifold, Mesh } from '../manifold-encapsulated-types';
import { Vec3 } from '../manifold-global-types';
import { GLTFNode } from './scene-builder.ts';
interface Morph {
    start?: (v: Vec3) => void;
    end?: (v: Vec3) => void;
}
export declare function cleanup(): void;
export declare function addMotion(doc: Document, type: 'translation' | 'rotation' | 'scale', node: GLTFNode, out: Node): Vec3 | null;
export declare function setMorph(doc: Document, node: Node, manifold: Manifold): void;
export declare const getMorph: (manifold: Manifold) => Morph | undefined;
export declare function morphStart(manifoldMesh: Mesh, morph?: Morph): number[];
export declare function morphEnd(doc: Document, manifoldMesh: Mesh, mesh: GLTFMesh, inputPositions: number[], morph?: Morph): void;
/**
 * Apply a morphing animation to the input manifold. Specify the start
 * function which will be applied to the vertex positions of the first frame and
 * linearly interpolated across the length of the overall animation. This
 * animation will only be shown if this manifold is used directly on a GLTFNode.
 *
 * @group Modelling Functions
 * @param manifold The object to add morphing animation to.
 * @param func A warping function to apply to the first animation frame.
 */
export declare const setMorphStart: (manifold: Manifold, func: (v: Vec3) => void) => void;
/**
 * Apply a morphing animation to the input manifold. Specify the end
 * function which will be applied to the vertex positions of the last frame and
 * linearly interpolated across the length of the overall animation. This
 * animation will only be shown if this manifold is used directly on a GLTFNode.
 *
 * @group Modelling Functions
 * @param manifold The object to add morphing animation to.
 * @param func A warping function to apply to the last animation frame.
 */
export declare const setMorphEnd: (manifold: Manifold, func: (v: Vec3) => void) => void;
export declare function addAnimationToDoc(doc: Document): void;
export declare function cleanupAnimationInDoc(): void;
export {};
